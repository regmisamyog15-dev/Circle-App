# QuickCircle

A polished Android assistive utility inspired by classic OEM assistive spheres (such as Lava's Background Play & assistive controls). Designed for accessibility, broken hardware button replacement, and seamless multitasking.

---

## 1. Background Play Architecture (Lava-Inspired)

QuickCircle's **Background Play** feature functions as an OEM-style system shortcut that transitions the user from an active media application to the Android Home screen while allowing the original application to maintain ownership of its media playback.

### Clean, Legitimate Architecture:
1. **Zero Artificial Audio**: QuickCircle **does not** create silent `AudioTrack` buffers, fake media notifications, or surrogate players.
2. **Session Ownership**: The target media application (Spotify, YouTube, VLC, browser video) remains the sole owner of its playback state and Android `MediaSession`.
3. **Sequence of Execution**:
   - **Query Active Session**: Detects active `MediaSession` controllers via Android's `MediaSessionManager` / `NotificationListenerService`.
   - **Identity Capture**: Records the target app's package name and `sessionToken`.
   - **Immediate Home Transition**: Executes `AccessibilityService.GLOBAL_ACTION_HOME` so the user is immediately taken to the Home screen without any intermediate QuickCircle activities or loading screens.
   - **Verification**: After a short, version-safe interval (~750 ms), re-queries active `MediaSession` controllers to verify whether the original target session is still in `STATE_PLAYING` / active buffering.
   - **Honest Feedback**:
     - If the target media session is still playing: QuickCircle does nothing (no intrusive success toasts). The user enjoys a seamless, native Home transition with audio continuing.
     - If the target application does not support background playback (e.g. paused upon losing focus without background entitlement): QuickCircle accurately displays *"This app doesn't support background playback."*
     - If no media session is active: Displays *"No active media."*

---

## 2. What Is Android-Supported vs. App-Dependent

| Capability | Support Status | Technical Mechanism |
|---|---|---|
| **Return to Home** | Full Support (Android 10+) | `AccessibilityService.GLOBAL_ACTION_HOME` / `Intent.CATEGORY_HOME` |
| **Media Session Querying** | Full Support (Android 10+) | Standard `MediaSessionManager.getActiveSessions()` |
| **Background Play Continuity** | **Depends on Target App** | If the target app is built to allow background playback (e.g., Spotify, podcast apps, music players, supported video apps), audio continues natively. If an app intentionally halts playback when moved to the background, third-party apps cannot force playback without violating system boundaries or DRM. |
| **Lock-Screen Playback** | Full Support | Maintained natively by the target application's active `MediaSession` and notification player. |
| **Software Volume Control** | Full Support | Direct `AudioManager.adjustStreamVolume` overrides. |

---

## 3. Battery & Privacy Principles
- **No Background Loops**: QuickCircle uses passive event triggers and runs a one-shot verification after triggering Background Play.
- **Zero Permanent WakeLocks**: No CPU wake locks or background audio streams are held.
- **Zero Data Collection**: No screen recording, no notification scraping, and no analytics.

## 4. Changes Made in This Pass

This project was audited and cleaned up. What changed:

- **Removed unused dependencies**: Firebase (BoM, AI, App Check), Room, Retrofit, Moshi, OkHttp, and their associated Gradle plugins (KSP, Secrets, Google Services) were declared but never referenced anywhere in the source — leftover from the Google AI Studio project template. Stripped from `build.gradle.kts`, `gradle/libs.versions.toml`, and `gradle.properties`. QuickCircle needs no network, database, or backend, so none of this should come back unless a real feature requires it.
- **Fixed mismatched icons**: the radial menu and volume panel were using generic AOSP notification/status-bar icons (e.g. `stat_notify_sync` for Volume Up, `stat_notify_missed_call` for Mute, `ic_menu_today` for Home) instead of icons that actually depict the action. Replaced with 15 purpose-built vector drawables (`res/drawable/ic_action_*.xml`) matching the app's own line-icon style. Also fixed the mute button, which previously only changed color on toggle and never swapped its icon.
- **Removed dead code**: an unused "media keeper" notification channel and two orphaned strings (`bg_play_title`, `bg_play_notification_text`) were vestigial from an earlier design and never actually posted to — removed them since QuickCircle intentionally never creates its own Background Play notification (see Section 1).
- **Removed unused imports** across `FloatingBubbleManager`, `QuickCircleAccessibilityService`, `MainSettingsScreen`, `OnboardingScreen`, `PermissionDialog`, `RadialOverlayView`.

## 5. What Still Needs Real-Device Testing

Everything above was verified by static source review, not by an actual Gradle/emulator build. Before shipping, run through this on a real device or emulator (Android Studio):

- `./gradlew clean assembleDebug` — first real compile since the dependency cleanup. Missing Gradle wrapper jar means Android Studio will offer to regenerate it on first open; accept that.
- Enable Accessibility + Overlay + Notification access, confirm the bubble appears and drags/docks correctly, position persists across restart.
- Volume +/-, mute, and the volume panel against real hardware volume changes.
- Screenshot and Split Screen on at least one Android 12+ and one Android 10/11 device (API availability differs).
- Triple-tap detection sensitivity in real use — it only fires on `TYPE_VIEW_CLICKED` accessibility events, so it won't catch taps on views that don't emit that event (e.g. some custom-drawn UI in other apps). Worth confirming this limitation is acceptable or needs a note in-app.
- Background Play against at least one app that supports background playback (e.g. a podcast/music app) and one that doesn't, to confirm the honest success/"unsupported" messaging.
- Battery Saver / Ultra Battery modes for any unexpected behavior.
- New vector icons at actual on-screen size (108dp radial menu radius) — check legibility, since they were designed but not visually verified on-device.
