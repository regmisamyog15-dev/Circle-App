package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.QuickCirclePreferences
import com.example.model.BatteryMode
import com.example.model.DockEdge
import com.example.model.QuickActionType
import com.example.model.StreamType
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.RoseError
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainSettingsScreen(
    preferences: QuickCirclePreferences,
    isAccessibilityGranted: Boolean,
    isOverlayGranted: Boolean,
    isMediaListenerGranted: Boolean = false,
    onRequestPermission: (com.example.ui.components.PermissionDialogType) -> Unit,
    onResetOnboarding: () -> Unit
) {
    val isEnabled by preferences.isEnabled.collectAsState()
    val isPermanent by preferences.isPermanent.collectAsState()
    val bubbleSizeDp by preferences.bubbleSizeDp.collectAsState()
    val bubbleOpacity by preferences.bubbleOpacity.collectAsState()
    val dockEdge by preferences.dockEdge.collectAsState()

    val isTripleTapEnabled by preferences.isTripleTapEnabled.collectAsState()
    val tripleTapSensitivityMs by preferences.tripleTapSensitivityMs.collectAsState()
    val batteryMode by preferences.batteryMode.collectAsState()

    val activeActions by preferences.activeActions.collectAsState()
    val isSoftwareVolumeReplacementEnabled by preferences.isSoftwareVolumeReplacementEnabled.collectAsState()
    val defaultStreamType by preferences.defaultStreamType.collectAsState()

    val isBackgroundPlayEnabled by preferences.isBackgroundPlayEnabled.collectAsState()
    val resumePausedMedia by preferences.resumePausedMedia.collectAsState()

    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Slate950
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "QuickCircle",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Slate50Text
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isEnabled && isAccessibilityGranted) EmeraldSuccess else RoseError)
                        )
                        Text(
                            text = if (isEnabled && isAccessibilityGranted) "Service Active" else "Setup Required",
                            fontSize = 12.sp,
                            color = Slate400
                        )
                    }
                }

                Switch(
                    checked = isEnabled,
                    onCheckedChange = { preferences.setEnabled(it) },
                    modifier = Modifier.testTag("master_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Slate950,
                        checkedTrackColor = CyanAccentLight
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Permissions Alert Banner if missing
            if (!isAccessibilityGranted || !isOverlayGranted) {
                PermissionWarningCard(
                    isAccessibilityGranted = isAccessibilityGranted,
                    isOverlayGranted = isOverlayGranted,
                    onRequestPermission = onRequestPermission
                )
                Spacer(modifier = Modifier.height(20.dp))
            }

            // SECTION: QuickCircle Bubble Settings
            SettingsSectionHeader(title = "QuickCircle", icon = Icons.Default.TouchApp)

            SettingsCard {
                // Visibility Mode
                Text("Visibility Mode", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterChip(
                        selected = isPermanent,
                        onClick = { preferences.setPermanent(true) },
                        label = { Text("Always Visible") },
                        colors = chipColors(),
                        modifier = Modifier.weight(1f).testTag("permanent_mode_chip")
                    )
                    FilterChip(
                        selected = !isPermanent,
                        onClick = { preferences.setPermanent(false) },
                        label = { Text("10s Auto-Hide") },
                        colors = chipColors(),
                        modifier = Modifier.weight(1f).testTag("autohide_mode_chip")
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Bubble Size Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Bubble Size", fontWeight = FontWeight.Medium, color = Slate50Text)
                    Text("${bubbleSizeDp} dp", color = CyanAccentLight, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = bubbleSizeDp.toFloat(),
                    onValueChange = { preferences.setBubbleSizeDp(it.toInt()) },
                    valueRange = 42f..66f,
                    steps = 5,
                    colors = sliderColors(),
                    modifier = Modifier.testTag("bubble_size_slider")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Bubble Opacity Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Bubble Opacity", fontWeight = FontWeight.Medium, color = Slate50Text)
                    Text("${(bubbleOpacity * 100).toInt()}%", color = CyanAccentLight, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = bubbleOpacity,
                    onValueChange = { preferences.setBubbleOpacity(it) },
                    valueRange = 0.3f..1.0f,
                    colors = sliderColors(),
                    modifier = Modifier.testTag("bubble_opacity_slider")
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Edge Docking
                Text("Screen Edge Docking", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DockEdge.values().forEach { edge ->
                        FilterChip(
                            selected = dockEdge == edge,
                            onClick = { preferences.setDockEdge(edge) },
                            label = { Text(edge.title.substringBefore(" ")) },
                            colors = chipColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Gesture Trigger
            SettingsSectionHeader(title = "Gesture Trigger", icon = Icons.Default.Widgets)

            SettingsCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Triple Tap (Accessibility Gesture)", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                        Text(
                            "Three quick taps on interactive elements wakes QuickCircle for 10 seconds. " +
                            "Note: detects accessibility click events, not taps on empty screen areas.",
                            fontSize = 12.sp,
                            color = Slate400
                        )
                    }
                    Switch(
                        checked = isTripleTapEnabled,
                        onCheckedChange = { preferences.setTripleTapEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Slate950,
                            checkedTrackColor = CyanAccentLight
                        ),
                        modifier = Modifier.testTag("triple_tap_switch")
                    )
                }

                if (isTripleTapEnabled) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sensitivity Window", fontWeight = FontWeight.Medium, color = Slate50Text)
                        Text("${tripleTapSensitivityMs} ms", color = CyanAccentLight, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = tripleTapSensitivityMs.toFloat(),
                        onValueChange = { preferences.setTripleTapSensitivityMs(it.toLong()) },
                        valueRange = 500f..1200f,
                        steps = 6,
                        colors = sliderColors()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Controls & Volume Replacement
            SettingsSectionHeader(title = "Controls & Volume", icon = Icons.Default.VolumeUp)

            SettingsCard {
                // Software Volume Replacement Note
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = CyanAccentLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Software Volume Replacement", fontWeight = FontWeight.Bold, color = Slate50Text)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "QuickCircle provides instant software volume controls when hardware keys are broken. It controls the single audio stream you select below (Media, Ringtone, Notification, or Call) — not every stream at once, and not always identical to what the physical buttons would have controlled.",
                    fontSize = 12.sp,
                    color = Slate400,
                    lineHeight = 18.sp
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Default Volume Stream
                Text("Default Stream to Control", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StreamType.values().forEach { stream ->
                        FilterChip(
                            selected = defaultStreamType == stream,
                            onClick = { preferences.setDefaultStreamType(stream) },
                            label = { Text(stream.title) },
                            colors = chipColors(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Radial Menu Actions
                Text("Radial Menu Actions (${activeActions.size} active)", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                Text("Tap items to include or exclude from the radial wheel", fontSize = 12.sp, color = Slate400)
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionType.values().forEach { action ->
                        val isSelected = activeActions.contains(action)
                        FilterChip(
                            selected = isSelected,
                            onClick = { preferences.toggleAction(action) },
                            label = { Text(action.title) },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isSelected) Icons.Default.Check else action.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = chipColors()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Background Play (Lava-Style)
            SettingsSectionHeader(title = "Background Play", icon = Icons.Default.PlayCircle)

            SettingsCard {
                Text(
                    text = "Return to Home while supported media continues playing.",
                    fontSize = 13.sp,
                    color = Slate400,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Enable Background Play
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Background Play", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                        Text(
                            "Keep supported media playing while you use other apps",
                            fontSize = 12.sp,
                            color = Slate400
                        )
                    }
                    Switch(
                        checked = isBackgroundPlayEnabled,
                        onCheckedChange = { preferences.setBackgroundPlayEnabled(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Slate950, checkedTrackColor = CyanAccentLight)
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Slate800)

                // Resume Paused Media
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Resume paused media", fontWeight = FontWeight.SemiBold, color = Slate50Text)
                        Text(
                            "Off by default. When on, Background Play will also press Play on a media " +
                            "session that is currently paused — including media you paused on purpose — " +
                            "before sending you Home.",
                            fontSize = 12.sp,
                            color = Slate400
                        )
                    }
                    Switch(
                        checked = resumePausedMedia,
                        onCheckedChange = { preferences.setResumePausedMedia(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Slate950, checkedTrackColor = CyanAccentLight)
                    )
                }

                // NOTE: "Show media controls on lock screen" and "Keep playback after lock"
                // settings have been removed. QuickCircle does not own the target app's
                // MediaSession and cannot control how that app shows its lock-screen controls.
                // Those are decisions made by the target app and Android, not QuickCircle.

                Spacer(modifier = Modifier.height(14.dp))

                // Battery Optimization Guidance Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Slate800)
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "Battery Optimization Guidance",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = CyanAccentLight
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "When returning to Home, QuickCircle does not use polling loops or screen scraping. Playback continuity is maintained by the target media app. If Android or OEM battery management kills the target app, QuickCircle will inform you.",
                            fontSize = 11.5.sp,
                            color = Slate400,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Battery Optimization
            SettingsSectionHeader(title = "Battery Optimization", icon = Icons.Default.BatteryChargingFull)

            SettingsCard {
                BatteryMode.values().forEach { mode ->
                    val isSelected = batteryMode == mode
                    OutlinedCard(
                        onClick = { preferences.setBatteryMode(mode) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (isSelected) Slate800 else Color.Transparent
                        ),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) CyanAccentLight else Slate800)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) CyanAccentLight else Slate700)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mode.title, fontWeight = FontWeight.Bold, color = Slate50Text)
                                Text(mode.description, fontSize = 12.sp, color = Slate400)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Slate800)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Why accessibility affects battery: Continuous high-frequency polling can drain power. QuickCircle uses passive event hooks without polling loops. Battery Saver suspends animations, and Ultra Battery turns off gesture listeners entirely.",
                        fontSize = 11.5.sp,
                        color = Slate400,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Accessibility & Permissions Status
            SettingsSectionHeader(title = "System Permissions", icon = Icons.Default.Security)

            SettingsCard {
                // Accessibility Status Row
                PermissionStatusRow(
                    title = "Accessibility Service",
                    subtitle = "Required for volume adjustments, screenshots, and system actions",
                    isGranted = isAccessibilityGranted,
                    onActionClick = {
                        onRequestPermission(com.example.ui.components.PermissionDialogType.ACCESSIBILITY)
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Overlay Status Row
                PermissionStatusRow(
                    title = "Display Over Other Apps",
                    subtitle = "Allows QuickCircle floating bubble to appear over active apps",
                    isGranted = isOverlayGranted,
                    onActionClick = {
                        onRequestPermission(com.example.ui.components.PermissionDialogType.OVERLAY)
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate800)

                // Media Session Detection Status Row
                PermissionStatusRow(
                    title = "Media Session Access (Optional)",
                    subtitle = "Enables detailed active player inspection for Background Play",
                    isGranted = isMediaListenerGranted,
                    onActionClick = {
                        onRequestPermission(com.example.ui.components.PermissionDialogType.MEDIA_LISTENER)
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION: Privacy & Transparency
            SettingsSectionHeader(title = "Privacy & Transparency", icon = Icons.Default.Lock)

            SettingsCard {
                Text(
                    text = "QuickCircle is built with zero telemetry. It never collects personal data, never uploads screenshots, never records screen contents, never listens to audio, and contains no ads.",
                    fontSize = 13.sp,
                    color = Slate400,
                    lineHeight = 19.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onResetOnboarding,
                    colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                    modifier = Modifier.fillMaxWidth().testTag("reset_onboarding_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Replay Onboarding Guide")
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 10.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = CyanAccentLight, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Slate50Text
        )
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            content()
        }
    }
}

@Composable
private fun PermissionStatusRow(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    onActionClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isGranted) EmeraldSuccess else RoseError)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontWeight = FontWeight.SemiBold, color = Slate50Text)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, fontSize = 12.sp, color = Slate400)
        }

        Button(
            onClick = onActionClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isGranted) Slate800 else CyanAccentLight
            )
        ) {
            Text(
                text = if (isGranted) "Enabled" else "Grant",
                color = if (isGranted) EmeraldSuccess else Slate950,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PermissionWarningCard(
    isAccessibilityGranted: Boolean,
    isOverlayGranted: Boolean,
    onRequestPermission: (com.example.ui.components.PermissionDialogType) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(AmberWarning)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = AmberWarning)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Permissions Needed", fontWeight = FontWeight.Bold, color = AmberWarning)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "QuickCircle needs Accessibility to execute volume & system actions, and Overlay for floating controls.",
                fontSize = 12.sp,
                color = Slate400
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isAccessibilityGranted) {
                    Button(
                        onClick = {
                            onRequestPermission(com.example.ui.components.PermissionDialogType.ACCESSIBILITY)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccentLight),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Accessibility", color = Slate950, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    }
                }
                if (!isOverlayGranted) {
                    Button(
                        onClick = {
                            onRequestPermission(com.example.ui.components.PermissionDialogType.OVERLAY)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Overlay", color = CyanAccentLight, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                    }
                }
            }
        }
    }
}

private val Slate50Text = Color(0xFFF8FAFC)

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = CyanAccentLight,
    selectedLabelColor = Slate950,
    selectedLeadingIconColor = Slate950,
    containerColor = Slate800,
    labelColor = Slate200,
    iconColor = Slate400
)

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = CyanAccentLight,
    activeTrackColor = CyanAccentLight,
    inactiveTrackColor = Slate800
)
