package com.example.service

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.data.QuickCirclePreferences
import com.example.model.BatteryMode
import com.example.overlay.FloatingBubbleManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

private const val TAG = "QuickCircle"

class QuickCircleAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var preferences: QuickCirclePreferences
    private lateinit var actionController: SystemActionController
    private var bubbleManager: FloatingBubbleManager? = null

    // Triple-tap detection via TYPE_VIEW_CLICKED events.
    //
    // IMPORTANT LIMITATION: This detects accessibility click events, NOT raw physical
    // screen taps. A tap on an empty area of the screen (with no clickable view) will
    // NOT register. This is an Android platform limitation — third-party apps cannot
    // intercept all raw touch events globally without a system-level overlay that
    // would block normal touch interaction.
    //
    // The feature is therefore labelled honestly in the UI as
    // "Triple Tap (accessibility gesture)" rather than "Triple Tap Anywhere".
    private val tapTimestamps = mutableListOf<Long>()

    // FIX (item 1): tracks which app is actually in the foreground, from
    // TYPE_WINDOW_STATE_CHANGED events — the legitimate, already-available
    // signal for this — so Background Play can target the session that
    // belongs to the app the user is actually looking at instead of just the
    // first playing session it finds. A regular Activity window reliably
    // fires this event; QuickCircle's own accessibility-overlay windows
    // (bubble/radial menu/volume panel) are TYPE_ACCESSIBILITY_OVERLAY, not
    // an Activity window, and do not.
    @Volatile
    private var lastForegroundPackage: String? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        preferences = QuickCirclePreferences.getInstance(this)
        actionController = SystemActionController(
            context = this,
            foregroundPackageProvider = { lastForegroundPackage },
            serviceProvider = { instance }
        )
        bubbleManager = FloatingBubbleManager(this, actionController)
        observePreferences()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (preferences.isEnabled.value) {
            bubbleManager?.showBubble()
        }
    }

    private fun observePreferences() {
        serviceScope.launch {
            preferences.isEnabled.collectLatest { enabled ->
                if (enabled) {
                    bubbleManager?.showBubble()
                } else {
                    bubbleManager?.hideBubble()
                }
            }
        }

        serviceScope.launch {
            preferences.bubbleSizeDp.collectLatest {
                bubbleManager?.updateAppearance()
            }
        }

        serviceScope.launch {
            preferences.bubbleOpacity.collectLatest {
                bubbleManager?.updateAppearance()
            }
        }

        serviceScope.launch {
            preferences.isPermanent.collectLatest { permanent ->
                if (!permanent) {
                    bubbleManager?.triggerTemporaryShow(10000L)
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // FIX (item 1): kept outside the battery-mode early-returns below on
        // purpose. This is a single field write, not a processing loop, so it
        // doesn't meaningfully affect Battery Saver/Ultra Battery's goal of
        // avoiding real work — and Background Play (which reads this) stays
        // correct even while a reduced battery mode is active.
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (!pkg.isNullOrEmpty() && pkg != packageName) {
                lastForegroundPackage = pkg
            }
        }

        // Ultra Battery: skip all passive event processing.
        // The service itself remains active (Android requirement), but we do no work here.
        if (preferences.batteryMode.value == BatteryMode.ULTRA_BATTERY) {
            return
        }

        // Battery Saver: also skip gesture detection to reduce processing overhead.
        if (preferences.batteryMode.value == BatteryMode.BATTERY_SAVER) {
            return
        }

        // Triple-tap via accessibility click events (Normal mode only).
        // See limitation note above: this does NOT detect taps on empty screen areas.
        if (preferences.isTripleTapEnabled.value && event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val now = SystemClock.uptimeMillis()
            tapTimestamps.add(now)

            val sensitivity = preferences.tripleTapSensitivityMs.value
            tapTimestamps.removeAll { now - it > sensitivity }

            if (tapTimestamps.size >= 3) {
                tapTimestamps.clear()
                bubbleManager?.triggerTemporaryShow(10000L)
            }
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "AccessibilityService interrupted")
    }

    override fun onDestroy() {
        instance = null
        try {
            bubbleManager?.hideBubble()
        } catch (e: Exception) {
            Log.w(TAG, "onDestroy: hideBubble failed", e)
        }
        // FIX (item 5): stop any pending Background Play verification callbacks
        // and background IO so they can't fire after this service is gone.
        actionController.cleanup()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: QuickCircleAccessibilityService? = null
            private set

        fun isServiceRunning(): Boolean = instance != null
    }
}
