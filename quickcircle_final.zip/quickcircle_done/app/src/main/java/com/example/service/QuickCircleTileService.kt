package com.example.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.data.QuickCirclePreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

@RequiresApi(Build.VERSION_CODES.N)
class QuickCircleTileService : TileService() {

    private lateinit var preferences: QuickCirclePreferences

    // FIX (item 25): collect preference changes while the QS panel is visible
    // so the tile stays current if the user toggles QuickCircle from the main app
    // while holding the panel open. The collector only runs between
    // onStartListening/onStopListening — no continuous background polling.
    private var listeningScope: CoroutineScope? = null
    private var listeningJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        preferences = QuickCirclePreferences.getInstance(this)
    }

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
        val scope = CoroutineScope(Dispatchers.Main)
        listeningScope = scope
        listeningJob = scope.launch {
            preferences.isEnabled.collect { updateTileState() }
        }
    }

    override fun onStopListening() {
        super.onStopListening()
        listeningJob?.cancel()
        listeningJob = null
        listeningScope?.cancel()
        listeningScope = null
    }

    override fun onClick() {
        super.onClick()
        val newState = !preferences.isEnabled.value
        preferences.setEnabled(newState)
        updateTileState()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val isEnabled = preferences.isEnabled.value
        tile.state = if (isEnabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "QuickCircle"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (isEnabled) "Active" else "Off"
        }
        tile.updateTile()
    }
}
