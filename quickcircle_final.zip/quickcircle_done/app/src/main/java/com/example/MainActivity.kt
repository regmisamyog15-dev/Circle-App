package com.example

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils.SimpleStringSplitter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.data.QuickCirclePreferences
import com.example.service.QuickCircleAccessibilityService
import com.example.service.QuickCircleNotificationListenerService
import com.example.ui.MainSettingsScreen
import com.example.ui.OnboardingScreen
import com.example.ui.components.PermissionDialogType
import com.example.ui.components.SimplePermissionDialog
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var preferences: QuickCirclePreferences
    private var isAccessibilityGranted by mutableStateOf(false)
    private var isOverlayGranted by mutableStateOf(false)
    private var isMediaListenerGranted by mutableStateOf(false)
    private var activePermissionDialog by mutableStateOf<PermissionDialogType?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        preferences = QuickCirclePreferences.getInstance(this)
        checkPermissions()

        setContent {
            MyApplicationTheme {
                val hasCompletedOnboarding by preferences.hasCompletedOnboarding.collectAsState()

                if (!hasCompletedOnboarding) {
                    OnboardingScreen(
                        isAccessibilityGranted = isAccessibilityGranted,
                        isOverlayGranted = isOverlayGranted,
                        onRequestPermission = { type ->
                            activePermissionDialog = type
                        },
                        onFinishOnboarding = {
                            if (!isAccessibilityGranted) {
                                activePermissionDialog = PermissionDialogType.ACCESSIBILITY
                            } else if (!isOverlayGranted) {
                                activePermissionDialog = PermissionDialogType.OVERLAY
                            } else {
                                preferences.setOnboardingCompleted(true)
                            }
                        }
                    )
                } else {
                    MainSettingsScreen(
                        preferences = preferences,
                        isAccessibilityGranted = isAccessibilityGranted,
                        isOverlayGranted = isOverlayGranted,
                        isMediaListenerGranted = isMediaListenerGranted,
                        onRequestPermission = { type ->
                            activePermissionDialog = type
                        },
                        onResetOnboarding = {
                            preferences.setOnboardingCompleted(false)
                        }
                    )
                }

                // Simple Allow / Deny Permission Dialog
                activePermissionDialog?.let { type ->
                    SimplePermissionDialog(
                        type = type,
                        onAllow = {
                            val currentType = activePermissionDialog
                            activePermissionDialog = null
                            handlePermissionAllow(currentType)
                        },
                        onDeny = {
                            val currentType = activePermissionDialog
                            activePermissionDialog = null
                            handlePermissionDeny(currentType)
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }

    private fun checkPermissions() {
        isAccessibilityGranted = isAccessibilityServiceEnabled(this)
        isOverlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        isMediaListenerGranted = isNotificationListenerEnabled(this)
    }

    private fun handlePermissionAllow(type: PermissionDialogType?) {
        when (type) {
            PermissionDialogType.ACCESSIBILITY -> {
                Toast.makeText(
                    this,
                    "Find 'QuickCircle' in Downloaded Services and toggle ON",
                    Toast.LENGTH_LONG
                ).show()
                openAccessibilitySettings()
            }
            PermissionDialogType.OVERLAY -> {
                Toast.makeText(
                    this,
                    "Turn on 'Allow display over other apps' for QuickCircle",
                    Toast.LENGTH_LONG
                ).show()
                openOverlaySettings()
            }
            PermissionDialogType.MEDIA_LISTENER -> {
                Toast.makeText(
                    this,
                    "Find 'QuickCircle' and enable Notification Access for Media Detection",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(this, "Notification Listener settings unavailable", Toast.LENGTH_SHORT).show()
                }
            }
            null -> {}
        }
    }

    private fun handlePermissionDeny(type: PermissionDialogType?) {
        when (type) {
            PermissionDialogType.ACCESSIBILITY -> {
                Toast.makeText(
                    this,
                    "Accessibility denied. QuickCircle features are paused until enabled.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            PermissionDialogType.OVERLAY -> {
                Toast.makeText(
                    this,
                    "Overlay denied. Floating button cannot appear above other apps.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            PermissionDialogType.MEDIA_LISTENER -> {
                Toast.makeText(
                    this,
                    "Media session access denied. QuickCircle will use standard audio detection.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            null -> {}
        }
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun openOverlaySettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
        } catch (_: Exception) {}
    }

    companion object {
        /**
         * FIX (item 26): Android's own enabled-services setting is the source of
         * truth. A non-null process-local `instance` only proves the service was
         * connected in THIS process at some point; it is not authoritative (e.g. a
         * stale reference surviving a race right after the user disables the
         * service in Settings, before onDestroy() runs). We check Settings first
         * and only fall back to the static instance if the Settings string cannot
         * be read at all (defensive; should not normally happen).
         */
        fun isAccessibilityServiceEnabled(context: Context): Boolean {
            val expectedComponent = ComponentName(context, QuickCircleAccessibilityService::class.java)
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )

            if (enabledServicesSetting != null) {
                val parser = SimpleStringSplitter(':')
                parser.setString(enabledServicesSetting)
                for (componentNameString in parser) {
                    val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                    if (enabledComponent != null && enabledComponent == expectedComponent) {
                        return true
                    }
                }
                return false
            }

            // Settings read failed (should not normally happen) — fall back to the
            // process-local instance as a best-effort signal only.
            return QuickCircleAccessibilityService.isServiceRunning()
        }

        /**
         * FIX (item 8): exact ComponentName match against the enabled
         * notification-listener list, instead of a substring/`contains` check
         * which could false-positive on a package name that is a substring of
         * another enabled listener's component string.
         */
        fun isNotificationListenerEnabled(context: Context): Boolean {
            val expectedComponent = ComponentName(context, QuickCircleNotificationListenerService::class.java)
            val enabledListenersSetting = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val parser = SimpleStringSplitter(':')
            parser.setString(enabledListenersSetting)
            for (componentNameString in parser) {
                val enabledComponent = ComponentName.unflattenFromString(componentNameString)
                if (enabledComponent != null && enabledComponent == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }
}
