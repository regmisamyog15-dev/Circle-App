package com.example

import android.app.Application
import com.example.data.QuickCirclePreferences

// NOTE: QuickCircle intentionally does not post any notification of its own
// for Background Play. Per the design principle in PHASE 6/9, the original
// media app remains the sole owner of its MediaSession, playback state, and
// any lock-screen/notification media controls. QuickCircle only queries and
// verifies that session — it never creates a substitute notification,
// foreground service, or "keeper" channel to fake continued playback.
class QuickCircleApplication : Application() {

    lateinit var preferences: QuickCirclePreferences
        private set

    override fun onCreate() {
        super.onCreate()
        preferences = QuickCirclePreferences.getInstance(this)
    }
}
