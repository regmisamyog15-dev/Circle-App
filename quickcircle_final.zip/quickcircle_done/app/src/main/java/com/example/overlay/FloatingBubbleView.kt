package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import com.example.model.DockEdge
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class FloatingBubbleView(
    context: Context,
    private var sizeDp: Int,
    private var baseOpacity: Float,
    private val onBubbleClicked: () -> Unit,
    private val onPositionUpdated: (Int, Int) -> Unit,
    private val onDragFinished: (Int, Int) -> Unit
) : View(context) {

    private val density = resources.displayMetrics.density
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    private val mainHandler = Handler(Looper.getMainLooper())

    // Paints
    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.rgb(56, 189, 248) // Cyan
        strokeWidth = 2.4f * density
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(225, 15, 23, 42) // Slate 900
    }

    private val centerCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.rgb(56, 189, 248)
    }

    private val centerWhiteDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    init {
        alpha = baseOpacity
    }

    fun updateAppearance(newSizeDp: Int, newOpacity: Float) {
        sizeDp = newSizeDp
        baseOpacity = newOpacity
        alpha = baseOpacity
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val px = (sizeDp * density).toInt()
        setMeasuredDimension(px, px)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = (width / 2f) - (3f * density)

        // Main circular body
        canvas.drawCircle(cx, cy, r, fillPaint)
        // Outer glowing ring
        canvas.drawCircle(cx, cy, r, outerRingPaint)
        // Concentric inner ring
        canvas.drawCircle(cx, cy, r * 0.58f, centerCorePaint)
        // Central white status dot
        canvas.drawCircle(cx, cy, r * 0.28f, centerWhiteDotPaint)
    }

    fun handleTouch(event: MotionEvent, currentX: Int, currentY: Int, screenWidth: Int, dockEdge: DockEdge): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = currentX
                initialY = currentY
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                alpha = 1.0f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY

                if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    isDragging = true
                }

                if (isDragging) {
                    val newX = (initialX + dx).toInt()
                    val newY = (initialY + dy).toInt()
                    onPositionUpdated(newX, newY)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                alpha = baseOpacity
                if (!isDragging) {
                    onBubbleClicked()
                } else {
                    // Dock to edge
                    snapToEdge(currentX, currentY, screenWidth, dockEdge)
                }
                return true
            }
        }
        return false
    }

    private fun snapToEdge(currX: Int, currY: Int, screenWidth: Int, dockEdge: DockEdge) {
        val bubbleW = width
        val targetX = when (dockEdge) {
            DockEdge.LEFT -> 8
            DockEdge.RIGHT -> (screenWidth - bubbleW - 8).coerceAtLeast(0)
            DockEdge.AUTO -> {
                val midpoint = screenWidth / 2
                if (currX + bubbleW / 2 < midpoint) 8 else (screenWidth - bubbleW - 8).coerceAtLeast(0)
            }
        }

        val animator = ValueAnimator.ofInt(currX, targetX).apply {
            duration = 200L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val animatedX = it.animatedValue as Int
                onPositionUpdated(animatedX, currY)
            }
        }
        animator.start()
        onDragFinished(targetX, currY)
    }
}
