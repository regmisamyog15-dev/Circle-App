package com.example.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.example.R
import com.example.model.QuickActionType
import kotlin.math.cos
import kotlin.math.sin

@SuppressLint("ViewConstructor")
class RadialOverlayView(
    context: Context,
    private val actions: List<QuickActionType>,
    private val centerX: Float,
    private val centerY: Float,
    private val onActionSelected: (QuickActionType) -> Unit,
    private val onDismissRequested: () -> Unit,
    // FIX (item 17): scale factor < 1.0 on small screens so the ring fits
    // without crashing. FloatingBubbleManager computes and passes this.
    private val scale: Float = 1f
) : View(context) {

    private val density = resources.displayMetrics.density
    private val radius = 108f * density * scale
    private val buttonRadius = 24f * density * scale
    private val centerButtonRadius = 28f * density * scale

    private var animProgress = 0f
    private val mainHandler = Handler(Looper.getMainLooper())
    private val autoDismissRunnable = Runnable { dismissWithAnimation() }

    // Paints
    private val scrimPaint = Paint().apply {
        color = Color.argb(100, 9, 13, 22)
        style = Paint.Style.FILL
    }

    private val diskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 15, 23, 42) // Slate 900 Glass
        style = Paint.Style.FILL
    }

    private val diskBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 56, 189, 248) // Cyan subtle accent border
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
    }

    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 30, 41, 59)
        style = Paint.Style.FILL
    }

    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 56, 189, 248)
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
    }

    private val actionButtonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 30, 41, 59)
        style = Paint.Style.FILL
    }

    private val actionBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 226, 232, 240)
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * density
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10.5f * density * scale  // FIX (item 17): scale with ring
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    // Cached drawables for actions
    private val actionDrawables = mutableMapOf<QuickActionType, Drawable>()
    private var closeDrawable: Drawable? = null

    init {
        loadDrawables()
        startEntranceAnimation()
        // Auto dismiss after 10 seconds of idle
        mainHandler.postDelayed(autoDismissRunnable, 10000L)
    }

    private fun loadDrawables() {
        closeDrawable = ContextCompat.getDrawable(context, R.drawable.ic_action_close)?.mutate()?.apply {
            setTint(Color.rgb(56, 189, 248))
        }

        for (action in actions) {
            val resId = getActionIconRes(action)
            val d = ContextCompat.getDrawable(context, resId)?.mutate()?.apply {
                setTint(Color.WHITE)
            }
            if (d != null) {
                actionDrawables[action] = d
            }
        }
    }

    private fun getActionIconRes(action: QuickActionType): Int {
        return when (action) {
            QuickActionType.VOLUME_UP -> R.drawable.ic_action_volume_up
            QuickActionType.VOLUME_DOWN -> R.drawable.ic_action_volume_down
            QuickActionType.VOLUME_MUTE -> R.drawable.ic_action_volume_mute
            QuickActionType.SCREENSHOT -> R.drawable.ic_action_screenshot
            QuickActionType.SPLIT_SCREEN -> R.drawable.ic_action_split_screen
            QuickActionType.BACKGROUND_PLAY -> R.drawable.ic_action_background_play
            QuickActionType.LOCK_SCREEN -> R.drawable.ic_action_lock
            QuickActionType.RECENTS -> R.drawable.ic_action_recents
            QuickActionType.QUICK_SETTINGS -> R.drawable.ic_action_quick_settings
            QuickActionType.HOME -> R.drawable.ic_action_home
            QuickActionType.NOTIFICATIONS -> R.drawable.ic_action_notifications
            QuickActionType.MEDIA_PLAY_PAUSE -> R.drawable.ic_action_media_play_pause
        }
    }

    private fun startEntranceAnimation() {
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240L
            interpolator = OvershootInterpolator(1.15f)
            addUpdateListener {
                animProgress = it.animatedValue as Float
                invalidate()
            }
        }
        animator.start()
    }

    fun dismissWithAnimation() {
        mainHandler.removeCallbacks(autoDismissRunnable)
        val animator = ValueAnimator.ofFloat(animProgress, 0f).apply {
            duration = 180L
            addUpdateListener {
                animProgress = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onDismissRequested()
                }
            })
        }
        animator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (animProgress <= 0.01f) return

        // Scrim background
        scrimPaint.alpha = (100 * animProgress).toInt()
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), scrimPaint)

        val currentRadius = radius * animProgress
        val wheelRadius = currentRadius + buttonRadius + 8f * density

        // Draw radial background disc
        canvas.drawCircle(centerX, centerY, wheelRadius, diskPaint)
        canvas.drawCircle(centerX, centerY, wheelRadius, diskBorderPaint)

        // Draw Center Hub
        val hubR = centerButtonRadius * animProgress
        canvas.drawCircle(centerX, centerY, hubR, centerPaint)
        canvas.drawCircle(centerX, centerY, hubR, centerBorderPaint)

        // Center close icon
        closeDrawable?.let { d ->
            val iconSize = (16 * density * animProgress).toInt()
            d.setBounds(
                (centerX - iconSize).toInt(),
                (centerY - iconSize).toInt(),
                (centerX + iconSize).toInt(),
                (centerY + iconSize).toInt()
            )
            d.draw(canvas)
        }

        // Draw Actions around the perimeter
        val count = actions.size
        if (count == 0) return

        val angleStep = (2 * Math.PI) / count
        // Start top-center: -PI/2
        val startAngle = -Math.PI / 2

        for (i in 0 until count) {
            val action = actions[i]
            val angle = startAngle + i * angleStep
            val bx = centerX + (currentRadius * cos(angle)).toFloat()
            val by = centerY + (currentRadius * sin(angle)).toFloat()

            val bR = buttonRadius * animProgress

            // Action button circle
            canvas.drawCircle(bx, by, bR, actionButtonPaint)
            canvas.drawCircle(bx, by, bR, actionBorderPaint)

            // Draw Icon
            val drawable = actionDrawables[action]
            if (drawable != null) {
                val iconSize = (13 * density * animProgress).toInt()
                drawable.setBounds(
                    (bx - iconSize).toInt(),
                    (by - iconSize - 2 * density).toInt(),
                    (bx + iconSize).toInt(),
                    (by + iconSize - 2 * density).toInt()
                )
                drawable.draw(canvas)
            }

            // Draw Short label
            if (animProgress > 0.7f) {
                textPaint.alpha = ((animProgress - 0.7f) / 0.3f * 255).toInt()
                val shortLabel = getActionShortTitle(action)
                canvas.drawText(shortLabel, bx, by + 12f * density, textPaint)
            }
        }
    }

    private fun getActionShortTitle(action: QuickActionType): String {
        return when (action) {
            QuickActionType.VOLUME_UP -> "Vol +"
            QuickActionType.VOLUME_DOWN -> "Vol -"
            QuickActionType.VOLUME_MUTE -> "Mute"
            QuickActionType.SCREENSHOT -> "Shot"
            QuickActionType.SPLIT_SCREEN -> "Split"
            QuickActionType.BACKGROUND_PLAY -> "BgPlay"
            QuickActionType.LOCK_SCREEN -> "Lock"
            QuickActionType.RECENTS -> "Recent"
            QuickActionType.QUICK_SETTINGS -> "Quick"
            QuickActionType.HOME -> "Home"
            QuickActionType.NOTIFICATIONS -> "Notif"
            QuickActionType.MEDIA_PLAY_PAUSE -> "Media"
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val tx = event.x
            val ty = event.y

            // Check if tapped center hub
            val distToCenter = Math.hypot((tx - centerX).toDouble(), (ty - centerY).toDouble()).toFloat()
            if (distToCenter <= centerButtonRadius * 1.3f) {
                dismissWithAnimation()
                return true
            }

            // Check actions
            val count = actions.size
            val angleStep = (2 * Math.PI) / count
            val startAngle = -Math.PI / 2

            for (i in 0 until count) {
                val action = actions[i]
                val angle = startAngle + i * angleStep
                val bx = centerX + (radius * cos(angle)).toFloat()
                val by = centerY + (radius * sin(angle)).toFloat()

                val dist = Math.hypot((tx - bx).toDouble(), (ty - by).toDouble()).toFloat()
                if (dist <= buttonRadius * 1.35f) {
                    onActionSelected(action)
                    dismissWithAnimation()
                    return true
                }
            }

            // Tapped outside radial menu
            dismissWithAnimation()
            return true
        }
        return super.onTouchEvent(event)
    }
}
