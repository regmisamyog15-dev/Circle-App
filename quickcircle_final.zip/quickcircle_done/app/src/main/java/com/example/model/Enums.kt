package com.example.model

enum class BatteryMode(val title: String, val description: String) {
    NORMAL(
        title = "Normal",
        description = "Floating button active, gesture detection active, smooth animations."
    ),
    BATTERY_SAVER(
        title = "Battery Saver",
        description = "Gesture detection paused, animations reduced. Bubble remains available on tap."
    ),
    ULTRA_BATTERY(
        title = "Ultra Battery",
        description = "Gesture detection disabled. Controls respond only to direct tap. " +
                "Note: The accessibility service remains active as required by Android."
    )
}

enum class DockEdge(val title: String) {
    AUTO("Auto (Nearest Edge)"),
    LEFT("Left Edge"),
    RIGHT("Right Edge")
}

enum class StreamType(val title: String, val streamId: Int) {
    MUSIC("Media", android.media.AudioManager.STREAM_MUSIC),
    RING("Ringtone", android.media.AudioManager.STREAM_RING),
    NOTIFICATION("Notification", android.media.AudioManager.STREAM_NOTIFICATION),
    VOICE_CALL("Call", android.media.AudioManager.STREAM_VOICE_CALL)
}
