package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CyanAccentLight
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

enum class PermissionDialogType(
    val title: String,
    val subtitle: String,
    val description: String,
    val icon: ImageVector
) {
    ACCESSIBILITY(
        title = "Allow Accessibility Access?",
        subtitle = "Core System Actions",
        description = "QuickCircle requires Accessibility permission to adjust volume, take screenshots, and trigger system actions without using broken hardware volume buttons. No personal data or screen content is ever recorded or transmitted.",
        icon = Icons.Default.Accessibility
    ),
    OVERLAY(
        title = "Allow Display Over Apps?",
        subtitle = "Floating Overlay",
        description = "QuickCircle needs permission to show the floating control circle and software volume panel on top of your apps so you can control your device from any screen.",
        icon = Icons.Default.Layers
    ),
    MEDIA_LISTENER(
        title = "Allow Media Session Access?",
        subtitle = "Active Player Detection",
        // FIX (item 7): Wording now describes the permission accurately rather
        // than making a behavioral promise ("never reads"). NotificationListenerService
        // grants the OS capability to read all notification content; QuickCircle's
        // code only calls MediaSessionManager.getActiveSessions() through it and
        // does not implement onNotificationPosted — so it cannot read notification
        // text even though the OS permission technically permits it.
        description = "This grants Android's Notification Access permission so QuickCircle can call MediaSessionManager.getActiveSessions() to detect which app is playing media. The app does not implement notification reading (onNotificationPosted is absent from the code) — it cannot read notification messages even though the underlying Android permission would allow it.",
        icon = Icons.Default.Security
    )
}

@Composable
fun SimplePermissionDialog(
    type: PermissionDialogType,
    onAllow: () -> Unit,
    onDeny: () -> Unit
) {
    Dialog(onDismissRequest = onDeny) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Slate900,
            shadowElevation = 24.dp,
            modifier = Modifier.fillMaxWidth().testTag("permission_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Icon Header
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Slate800),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = type.icon,
                        contentDescription = null,
                        tint = CyanAccentLight,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Subtitle Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Slate800)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = type.subtitle.uppercase(),
                        color = CyanAccentLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Title
                Text(
                    text = type.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                Text(
                    text = type.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate400,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons: Simple Allow & Deny
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Deny Button
                    OutlinedButton(
                        onClick = onDeny,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("permission_deny_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Slate800,
                            contentColor = Color.White
                        ),
                        border = null
                    ) {
                        Text("Deny", fontWeight = FontWeight.SemiBold)
                    }

                    // Allow Button
                    Button(
                        onClick = onAllow,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("permission_allow_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccentLight,
                            contentColor = Slate950
                        )
                    ) {
                        Text("Allow", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
