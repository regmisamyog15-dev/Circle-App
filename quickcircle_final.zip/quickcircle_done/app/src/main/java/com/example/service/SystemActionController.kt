package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.HardwareBuffer
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.widget.Toast
import com.example.data.QuickCirclePreferences
import com.example.model.QuickActionType
import com.example.model.StreamType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

private const val TAG = "QuickCircle"

class SystemActionController(
    private val context: Context,
    // FIX (item 1): lets the caller (the AccessibilityService, which observes
    // TYPE_WINDOW_STATE_CHANGED events) tell us which app is actually in the
    // foreground. Defaults to "unknown" so existing callers/tests that don't
    // supply one keep compiling and behave the same as before (fail-safe path).
    private val foregroundPackageProvider: () -> String? = { null },
    private val serviceProvider: () -> AccessibilityService?
) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val preferences = QuickCirclePreferences.getInstance(context)

    // Reusable coroutine scope for background work (screenshot IO etc.)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // FIX (items 4 & 5): identifies the current Background Play operation so a
    // stale verification callback from an older call can recognize it's stale
    // and stay silent, plus a token so all pending Background Play Handler
    // callbacks can be removed together on cleanup().
    private val backgroundPlayGeneration = AtomicInteger(0)
    private val backgroundPlayCallbackToken = Any()
    @Volatile private var isDestroyed = false

    /**
     * FIX (item 5): must be called from the owning service's onDestroy() (or
     * equivalent) so pending Background Play verification callbacks don't fire
     * after the service/controller is gone and touch a dead context, and so no
     * stale toast can appear after teardown. Also stops background IO work.
     */
    fun cleanup() {
        isDestroyed = true
        mainHandler.removeCallbacksAndMessages(backgroundPlayCallbackToken)
        ioScope.cancel()
    }

    fun performAction(actionType: QuickActionType, onVolumeChanged: ((Int, Int, Boolean) -> Unit)? = null) {
        // FIX (item 32): Ultra Battery mode should minimise processing — vibration
        // contradicts that goal and is skipped in that mode.
        if (preferences.batteryMode.value != com.example.model.BatteryMode.ULTRA_BATTERY) {
            vibrateFeedback()
        }
        when (actionType) {
            QuickActionType.VOLUME_UP -> adjustVolume(1, onVolumeChanged)
            QuickActionType.VOLUME_DOWN -> adjustVolume(-1, onVolumeChanged)
            QuickActionType.VOLUME_MUTE -> toggleMute(onVolumeChanged)
            QuickActionType.SCREENSHOT -> takeScreenshot()
            QuickActionType.SPLIT_SCREEN -> toggleSplitScreen()
            QuickActionType.BACKGROUND_PLAY -> activateBackgroundPlay()
            QuickActionType.LOCK_SCREEN -> lockScreen()
            QuickActionType.RECENTS -> performGlobal(AccessibilityService.GLOBAL_ACTION_RECENTS)
            QuickActionType.QUICK_SETTINGS -> performGlobal(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            QuickActionType.HOME -> performGlobal(AccessibilityService.GLOBAL_ACTION_HOME)
            QuickActionType.NOTIFICATIONS -> performGlobal(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            QuickActionType.MEDIA_PLAY_PAUSE -> toggleMediaPlayPause()
        }
    }

    fun adjustVolume(direction: Int, callback: ((Int, Int, Boolean) -> Unit)? = null) {
        val stream = preferences.defaultStreamType.value.streamId
        val flag = AudioManager.FLAG_PLAY_SOUND
        val adjustDir = if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        try {
            audioManager.adjustStreamVolume(stream, adjustDir, flag)
        } catch (e: SecurityException) {
            Log.w(TAG, "adjustVolume: SecurityException for stream $stream", e)
        } catch (e: Exception) {
            Log.w(TAG, "adjustVolume: unexpected error", e)
        }
        callback?.invoke(getStreamVolume(stream), getStreamMaxVolume(stream), isStreamMuted(stream))
    }

    // FIX (item 33): added playSound parameter so VolumeOverlayView can suppress
    // the system "beep" while the user is actively dragging and only fire it once
    // on release. Discrete +/- button taps keep playSound = true (default).
    fun setVolume(progress: Int, playSound: Boolean = true, callback: ((Int, Int, Boolean) -> Unit)? = null) {
        val stream = preferences.defaultStreamType.value.streamId
        val flag = if (playSound) AudioManager.FLAG_PLAY_SOUND else 0
        try {
            audioManager.setStreamVolume(stream, progress, flag)
        } catch (e: SecurityException) {
            Log.w(TAG, "setVolume: SecurityException for stream $stream", e)
        } catch (e: Exception) {
            Log.w(TAG, "setVolume: unexpected error", e)
        }
        callback?.invoke(getStreamVolume(stream), getStreamMaxVolume(stream), isStreamMuted(stream))
    }

    // FIX (item 23): report the mute state Android actually reports after the
    // attempt, not the assumed !isCurrentlyMuted. If adjustStreamVolume() threw
    // or was silently ignored by the platform (fixed-volume device, DND, etc.)
    // isStreamMuted() below reflects the true outcome instead of a guess.
    fun toggleMute(callback: ((Int, Int, Boolean) -> Unit)? = null) {
        val stream = preferences.defaultStreamType.value.streamId
        val isCurrentlyMuted = isStreamMuted(stream)
        val flag = AudioManager.FLAG_PLAY_SOUND
        try {
            if (isCurrentlyMuted) {
                audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, flag)
            } else {
                audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, flag)
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "toggleMute: SecurityException for stream $stream", e)
        } catch (e: Exception) {
            Log.w(TAG, "toggleMute: unexpected error", e)
        }
        callback?.invoke(getStreamVolume(stream), getStreamMaxVolume(stream), isStreamMuted(stream))
    }

    fun getVolumeInfo(): Triple<Int, Int, Boolean> {
        val stream = preferences.defaultStreamType.value.streamId
        return Triple(getStreamVolume(stream), getStreamMaxVolume(stream), isStreamMuted(stream))
    }

    private fun getStreamVolume(stream: Int): Int = try {
        audioManager.getStreamVolume(stream)
    } catch (e: Exception) {
        Log.w(TAG, "getStreamVolume failed for stream $stream", e)
        0
    }

    private fun getStreamMaxVolume(stream: Int): Int = try {
        audioManager.getStreamMaxVolume(stream).coerceAtLeast(1)
    } catch (e: Exception) {
        Log.w(TAG, "getStreamMaxVolume failed for stream $stream", e)
        15
    }

    private fun isStreamMuted(stream: Int): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioManager.isStreamMute(stream)
        } else {
            audioManager.getStreamVolume(stream) == 0
        }
    } catch (e: Exception) {
        Log.w(TAG, "isStreamMuted failed for stream $stream", e)
        false
    }

    // ─── SCREENSHOT ────────────────────────────────────────────────────────────
    // FIX: Previously the ScreenshotResult was received but never persisted.
    // Now: HardwareBuffer → Bitmap → MediaStore. Success toast only after save.
    // Reuses ioScope instead of creating a new executor per screenshot.

    private fun takeScreenshot() {
        val service = serviceProvider()
        if (service == null) {
            showToast("Accessibility Service not connected")
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            service.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                // Use ioScope's executor equivalent; we launch coroutine from callback
                context.mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshotResult: AccessibilityService.ScreenshotResult) {
                        // Persist on IO thread; show result on main thread
                        ioScope.launch {
                            val saved = saveScreenshotResult(screenshotResult)
                            withContext(Dispatchers.Main) {
                                if (saved) {
                                    showToast("Screenshot saved")
                                } else {
                                    showToast("Screenshot failed to save")
                                }
                            }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        val msg = when (errorCode) {
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW ->
                                "Cannot capture: screen content is protected"
                            AccessibilityService.ERROR_TAKE_SCREENSHOT_INVALID_DISPLAY ->
                                "Cannot capture: invalid display"
                            3 -> // ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_MS
                                "Please wait before capturing again"
                            else -> "Screenshot failed (code $errorCode)"
                        }
                        showToast(msg)
                    }
                }
            )
        } else {
            // Android 10 (Q) and below: fall back to system global action
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            if (!success) {
                showToast("Screenshot not supported on this device")
            }
            // Note: GLOBAL_ACTION_TAKE_SCREENSHOT on older devices is handled by the OS;
            // we cannot verify the save ourselves via MediaStore.
        }
    }

    /**
     * Converts ScreenshotResult → Bitmap → MediaStore entry.
     * Returns true only if the MediaStore insertion and stream write both succeed.
     * All resources are released in a finally block.
     */
    private fun saveScreenshotResult(result: AccessibilityService.ScreenshotResult): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false

        var hardwareBuffer: HardwareBuffer? = null
        var bitmap: Bitmap? = null

        return try {
            hardwareBuffer = result.hardwareBuffer
            if (hardwareBuffer == null) {
                Log.e(TAG, "saveScreenshotResult: HardwareBuffer is null")
                return false
            }

            // Convert HardwareBuffer → Bitmap
            bitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, null)
            if (bitmap == null) {
                Log.e(TAG, "saveScreenshotResult: Bitmap.wrapHardwareBuffer returned null")
                return false
            }

            // HardwareBuffer-backed bitmaps cannot be compressed directly;
            // copy to a software bitmap first.
            val softBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
            if (softBitmap == null) {
                Log.e(TAG, "saveScreenshotResult: copy to software bitmap failed")
                return false
            }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            // FIX (item 20): append nanosecond suffix to prevent filename collisions
            // when two screenshots are taken within the same second. SimpleDateFormat
            // only has second resolution; MediaStore may silently rename duplicates
            // on some Android versions instead of reliably de-duplicating.
            val uniqueSuffix = System.nanoTime().toString().takeLast(6)
            val fileName = "Screenshot_${timestamp}_$uniqueSuffix.png"

            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            if (uri == null) {
                Log.e(TAG, "saveScreenshotResult: MediaStore.insert returned null URI")
                return false
            }

            var writeSuccess = false
            try {
                resolver.openOutputStream(uri)?.use { stream ->
                    writeSuccess = softBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }
            } catch (e: IOException) {
                Log.e(TAG, "saveScreenshotResult: IOException writing bitmap", e)
                resolver.delete(uri, null, null)
                return false
            }

            if (!writeSuccess) {
                Log.e(TAG, "saveScreenshotResult: bitmap.compress returned false")
                resolver.delete(uri, null, null)
                return false
            }

            // FIX (item 21): check IS_PENDING update return value. If the update
            // fails (returns 0 rows), the image row is orphaned (pending = 1 forever,
            // invisible in the gallery). In that case, delete the orphaned row and
            // report failure rather than silently leaving a ghost entry.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val update = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                val rowsUpdated = resolver.update(uri, update, null, null)
                if (rowsUpdated <= 0) {
                    Log.e(TAG, "saveScreenshotResult: failed to clear IS_PENDING — cleaning up orphaned row")
                    resolver.delete(uri, null, null)
                    return false
                }
            }

            softBitmap.recycle()
            true
        } catch (e: SecurityException) {
            Log.e(TAG, "saveScreenshotResult: SecurityException", e)
            false
        } catch (e: Exception) {
            Log.e(TAG, "saveScreenshotResult: unexpected error", e)
            false
        } finally {
            bitmap?.recycle()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                hardwareBuffer?.close()
            }
        }
    }

    // ─── SPLIT SCREEN ──────────────────────────────────────────────────────────
    // FIX: Now checks getSystemActions() before attempting toggle.

    private fun toggleSplitScreen() {
        val service = serviceProvider()
        if (service == null) {
            showToast("Accessibility Service not connected")
            return
        }

        // Check whether split-screen action is available in the current state
        val systemActions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                service.systemActions?.map { it.id } ?: emptyList()
            } catch (e: Exception) {
                Log.w(TAG, "toggleSplitScreen: getSystemActions failed", e)
                emptyList()
            }
        } else {
            emptyList<Int>()
        }

        val splitScreenActionId = AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN
        val actionAvailable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            systemActions.contains(splitScreenActionId)
        } else {
            true // Best-effort on older APIs; rely on performGlobalAction return value
        }

        if (!actionAvailable) {
            showToast("Split screen isn't available on this device or in this state")
            return
        }

        val success = service.performGlobalAction(splitScreenActionId)
        if (!success) {
            showToast("Split screen isn't available on this device or in this state")
        }
    }

    private fun lockScreen() {
        val service = serviceProvider()
        if (service == null) {
            showToast("Accessibility Service not connected")
            return
        }
        val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        if (!success) {
            showToast("Lock screen action unavailable")
        }
    }

    private fun performGlobal(action: Int) {
        val service = serviceProvider()
        if (service == null) {
            showToast("Accessibility Service not connected")
            return
        }
        try {
            val success = service.performGlobalAction(action)
            if (!success) {
                Log.w(TAG, "performGlobal: action $action returned false")
            }
        } catch (e: Exception) {
            Log.e(TAG, "performGlobal: exception for action $action", e)
        }
    }

    // ─── MEDIA PLAY/PAUSE ──────────────────────────────────────────────────────
    // FIX: Prefers MediaController.TransportControls over global key dispatch.

    private fun toggleMediaPlayPause() {
        // Try to target the active media session directly
        val targeted = tryTargetedMediaPlayPause()
        if (!targeted) {
            // Fall back to global key event as a last resort
            try {
                val eventDown = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                val eventUp = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                audioManager.dispatchMediaKeyEvent(eventDown)
                audioManager.dispatchMediaKeyEvent(eventUp)
            } catch (e: Exception) {
                Log.w(TAG, "toggleMediaPlayPause: global key dispatch failed", e)
                showToast("No active media session found")
            }
        }
    }

    /**
     * Returns true if a specific MediaController was found and toggled.
     * Returns false if no usable session was available.
     */
    private fun tryTargetedMediaPlayPause(): Boolean {
        val controllers = QuickCircleNotificationListenerService.getActiveControllers(context)
        if (controllers.isEmpty()) return false

        // Prefer a currently playing session; fall back to any session
        val target = controllers.firstOrNull { controller ->
            val state = controller.playbackState?.state ?: PlaybackState.STATE_NONE
            state == PlaybackState.STATE_PLAYING ||
            state == PlaybackState.STATE_BUFFERING ||
            state == PlaybackState.STATE_FAST_FORWARDING ||
            state == PlaybackState.STATE_REWINDING
        } ?: controllers.firstOrNull { controller ->
            controller.playbackState?.state == PlaybackState.STATE_PAUSED
        } ?: return false

        return try {
            val controls = target.transportControls ?: return false
            val state = target.playbackState?.state ?: PlaybackState.STATE_NONE
            if (state == PlaybackState.STATE_PLAYING ||
                state == PlaybackState.STATE_BUFFERING ||
                state == PlaybackState.STATE_FAST_FORWARDING ||
                state == PlaybackState.STATE_REWINDING
            ) {
                controls.pause()
            } else {
                controls.play()
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "tryTargetedMediaPlayPause: TransportControls failed", e)
            false
        }
    }

    // ─── BACKGROUND PLAY ───────────────────────────────────────────────────────
    // FIX: Multi-interval same-session verification; no isMusicActive as proof.

    /**
     * Testable selection logic (item 37): picks which MediaController Background
     * Play should target, given the full session list and (if known) the
     * foreground package. Pure function — no Android service calls — so it can
     * be unit tested directly.
     *
     * FIX (item 1): prefers a session that belongs to the actual foreground
     * app. If the foreground package is known but has no playing/pausable
     * session of its own, we do NOT fall back to a different app's session —
     * that is exactly the "wrong app" bug this fixes. We only guess when the
     * foreground app is unknown AND there is exactly one unambiguous
     * candidate; with 0 or 2+ candidates and no foreground signal we fail
     * safe (return null) rather than pick arbitrarily.
     */
    internal fun selectBackgroundPlayTarget(
        controllers: List<MediaController>,
        foregroundPackage: String?,
        allowResumingPaused: Boolean
    ): MediaController? {
        fun isActivelyPlaying(c: MediaController): Boolean {
            val state = c.playbackState?.state ?: PlaybackState.STATE_NONE
            return state == PlaybackState.STATE_PLAYING ||
                state == PlaybackState.STATE_BUFFERING ||
                state == PlaybackState.STATE_CONNECTING ||
                state == PlaybackState.STATE_FAST_FORWARDING ||
                state == PlaybackState.STATE_REWINDING
        }

        val playing = controllers.filter { isActivelyPlaying(it) }

        val playingTarget = when {
            foregroundPackage != null -> playing.firstOrNull { it.packageName == foregroundPackage }
            playing.size == 1 -> playing.first()
            else -> null // ambiguous (2+ candidates) or none — do not guess
        }
        if (playingTarget != null) return playingTarget

        if (!allowResumingPaused) return null

        val paused = controllers.filter { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        return when {
            foregroundPackage != null -> paused.firstOrNull { it.packageName == foregroundPackage }
            paused.size == 1 -> paused.first()
            else -> null
        }
    }

    fun activateBackgroundPlay() {
        if (!preferences.isBackgroundPlayEnabled.value) {
            showToast("Background Play is disabled in settings")
            return
        }

        val controllers = QuickCircleNotificationListenerService.getActiveControllers(context)
        // FIX (item 1): determine the actual foreground app via the
        // AccessibilityService's window-state tracking rather than blindly
        // taking the first active/playing session (which could belong to an
        // unrelated background app, e.g. Spotify, while YouTube is on screen).
        val foregroundPackage = foregroundPackageProvider()

        val targetController: MediaController? = selectBackgroundPlayTarget(
            controllers,
            foregroundPackage,
            preferences.resumePausedMedia.value
        )

        // FIX: Do NOT use isMusicActive as fallback proof, and do NOT fall back
        // across apps when we know the foreground app but it has no session of
        // its own — we honestly report that instead of guessing.
        if (targetController == null) {
            showToast("No active media session detected")
            return
        }

        // Capture target identity before HOME
        val targetPackageName = targetController.packageName
        val targetSessionToken = targetController.sessionToken

        // If user wants to resume paused media, attempt resume before going home
        if (targetController.playbackState?.state == PlaybackState.STATE_PAUSED &&
            preferences.resumePausedMedia.value
        ) {
            try {
                targetController.transportControls?.play()
            } catch (e: Exception) {
                Log.w(TAG, "activateBackgroundPlay: resume play failed", e)
            }
        }

        // Navigate HOME
        val service = serviceProvider()
        var homeTriggered = false

        if (service != null) {
            try {
                homeTriggered = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            } catch (e: Exception) {
                Log.w(TAG, "activateBackgroundPlay: HOME action failed", e)
            }
        }

        if (!homeTriggered) {
            try {
                val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(homeIntent)
                homeTriggered = true
            } catch (e: Exception) {
                Log.w(TAG, "activateBackgroundPlay: startActivity HOME failed", e)
            }
        }

        if (!homeTriggered) {
            showToast("Could not navigate home")
            return
        }

        // FIX: Multi-interval verification at 250, 500, 1000, 2000, 3000 ms.
        // Each check looks for the SAME session (strict identity — item 2).
        // isMusicActive is NOT used to determine success.
        //
        // FIX (items 4 & 5): each call gets a new "generation". A stale
        // callback from a previous call checks the generation counter before
        // doing anything and silently abandons itself if a newer operation has
        // since started — so Request A's verification can never show a
        // (possibly stale/incorrect) result for Request B, and pending
        // callbacks can be swept in cleanup() via the shared token.
        val myGeneration = backgroundPlayGeneration.incrementAndGet()
        mainHandler.removeCallbacksAndMessages(backgroundPlayCallbackToken)
        scheduleSessionVerification(targetPackageName, targetSessionToken, 0, myGeneration)
    }

    private val verificationDelaysMs = longArrayOf(250, 500, 1000, 2000, 3000)

    private fun scheduleSessionVerification(
        targetPackage: String,
        targetToken: android.media.session.MediaSession.Token?,
        checkIndex: Int,
        generation: Int
    ) {
        if (checkIndex >= verificationDelaysMs.size) return

        val delay = if (checkIndex == 0) {
            verificationDelaysMs[0]
        } else {
            verificationDelaysMs[checkIndex] - verificationDelaysMs[checkIndex - 1]
        }

        val runnable = Runnable {
            // A newer Background Play call (or teardown) has since happened —
            // this result is stale, abandon silently rather than showing a
            // toast that belongs to an operation the user has moved past.
            if (isDestroyed || generation != backgroundPlayGeneration.get()) return@Runnable

            val postControllers = QuickCircleNotificationListenerService.getActiveControllers(context)

            // FIX (item 2): STRICT session identity. If we captured a session
            // token, only that exact token counts as "the same session" — we
            // never silently fall back to package-only matching, since a
            // package can expose multiple/rotating sessions and a package-only
            // match could verify a completely different session as if it were
            // the one the user started. If identity can't be confirmed, that is
            // treated as verification failure, not success.
            val postTarget = if (targetToken != null) {
                postControllers.firstOrNull { it.sessionToken == targetToken }
            } else {
                postControllers.firstOrNull { it.packageName == targetPackage }
            }

            val postState = postTarget?.playbackState?.state ?: PlaybackState.STATE_NONE
            val isStillPlaying = postState == PlaybackState.STATE_PLAYING ||
                    postState == PlaybackState.STATE_BUFFERING ||
                    postState == PlaybackState.STATE_CONNECTING

            if (isStillPlaying) {
                // Target is confirmed still playing — no toast, no fake success message.
                // The user already sees the home screen; silence is correct here.
                // Cancel remaining checks (session confirmed)
                return@Runnable
            }

            // If this is the last check and still not playing, report failure
            if (checkIndex == verificationDelaysMs.size - 1) {
                showToast("This app doesn't support background playback")
                return@Runnable
            }

            // Otherwise keep polling (same generation)
            scheduleSessionVerification(targetPackage, targetToken, checkIndex + 1, generation)
        }
        mainHandler.postDelayed(runnable, backgroundPlayCallbackToken, delay)
    }

    // ─── VIBRATION ─────────────────────────────────────────────────────────────

    private fun vibrateFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(20)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "vibrateFeedback: failed", e)
        }
    }

    private fun showToast(message: String) {
        mainHandler.post {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}
