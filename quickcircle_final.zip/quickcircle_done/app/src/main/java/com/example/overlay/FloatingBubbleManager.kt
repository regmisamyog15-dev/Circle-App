package com.example.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import com.example.data.QuickCirclePreferences
import com.example.model.QuickActionType
import com.example.service.SystemActionController
import kotlin.math.roundToInt

private const val TAG = "QuickCircle"

class FloatingBubbleManager(
    private val context: Context,
    private val actionController: SystemActionController
) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val preferences = QuickCirclePreferences.getInstance(context)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var bubbleView: FloatingBubbleView? = null
    private var bubbleLayoutParams: WindowManager.LayoutParams? = null

    private var radialOverlayView: RadialOverlayView? = null
    private var volumeOverlayView: VolumeOverlayView? = null

    private var isBubbleAttached = false
    private var isTemporaryMode = false

    private val autoHideRunnable = Runnable {
        if (!preferences.isPermanent.value || isTemporaryMode) {
            hideBubble()
            isTemporaryMode = false
        }
    }

    private val overlayType: Int
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        }

    fun showBubble(temporaryDurationMs: Long? = null) {
        if (!preferences.isEnabled.value) return

        mainHandler.removeCallbacks(autoHideRunnable)
        if (temporaryDurationMs != null) {
            isTemporaryMode = true
            mainHandler.postDelayed(autoHideRunnable, temporaryDurationMs)
        } else if (!preferences.isPermanent.value) {
            mainHandler.postDelayed(autoHideRunnable, 10000L)
        }

        if (isBubbleAttached && bubbleView != null) {
            bubbleView?.visibility = android.view.View.VISIBLE
            return
        }

        val density = context.resources.displayMetrics.density
        val sizeDp = preferences.bubbleSizeDp.value
        val opacity = preferences.bubbleOpacity.value
        val sizePx = (sizeDp * density).toInt()

        val safeBounds = getSafeBounds(sizePx)

        var posX = preferences.positionX.value
        var posY = preferences.positionY.value

        // FIX: Always clamp restored position to current safe bounds.
        // This handles rotation, display-size changes, and resolution switches.
        if (posX < 0 || posY < 0) {
            // Default: right edge, 45% down
            posX = safeBounds.right
            posY = ((safeBounds.top + safeBounds.bottom) * 0.45f).roundToInt()
        } else {
            posX = posX.coerceIn(safeBounds.left, safeBounds.right)
            posY = posY.coerceIn(safeBounds.top, safeBounds.bottom)
        }

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = posX
            y = posY
        }
        bubbleLayoutParams = params

        bubbleView = FloatingBubbleView(
            context = context,
            sizeDp = sizeDp,
            baseOpacity = opacity,
            onBubbleClicked = {
                handleBubbleTap()
            },
            onPositionUpdated = { newX, newY ->
                updateBubblePosition(newX, newY)
            },
            onDragFinished = { finalX, finalY ->
                // Clamp before saving so the persisted value is always valid
                val savedBounds = getSafeBounds(sizePx)
                val clampedX = finalX.coerceIn(savedBounds.left, savedBounds.right)
                val clampedY = finalY.coerceIn(savedBounds.top, savedBounds.bottom)
                preferences.savePosition(clampedX, clampedY)
                resetIdleTimeout()
            }
        ).apply {
            setOnTouchListener { _, event ->
                val currX = bubbleLayoutParams?.x ?: 0
                val currY = bubbleLayoutParams?.y ?: 0
                val screenW = getScreenDimensions().x
                val edge = preferences.dockEdge.value
                handleTouch(event, currX, currY, screenW, edge)
            }
        }

        try {
            windowManager.addView(bubbleView, params)
            isBubbleAttached = true
        } catch (e: SecurityException) {
            Log.e(TAG, "showBubble: overlay permission denied", e)
            isBubbleAttached = false
        } catch (e: Exception) {
            Log.e(TAG, "showBubble: addView failed", e)
            isBubbleAttached = false
        }
    }

    fun hideBubble() {
        mainHandler.removeCallbacks(autoHideRunnable)
        hideRadialMenu()
        hideVolumePanel()

        if (isBubbleAttached && bubbleView != null) {
            try {
                windowManager.removeView(bubbleView)
            } catch (e: Exception) {
                Log.w(TAG, "hideBubble: removeView failed", e)
            }
            bubbleView = null
            isBubbleAttached = false
        }
    }

    fun triggerTemporaryShow(durationMs: Long = 10000L) {
        if (!isBubbleAttached) {
            showBubble(durationMs)
        } else {
            bubbleView?.visibility = android.view.View.VISIBLE
            mainHandler.removeCallbacks(autoHideRunnable)
            mainHandler.postDelayed(autoHideRunnable, durationMs)
        }
    }

    fun updateAppearance() {
        val sizeDp = preferences.bubbleSizeDp.value
        val opacity = preferences.bubbleOpacity.value
        bubbleView?.updateAppearance(sizeDp, opacity)

        val density = context.resources.displayMetrics.density
        val sizePx = (sizeDp * density).toInt()

        bubbleLayoutParams?.let { params ->
            params.width = sizePx
            params.height = sizePx

            // FIX (item 16): re-clamp X/Y to the NEW safe bounds for the new size.
            // Without this, enlarging the bubble while it's near the right or bottom
            // edge leaves it partially off-screen — the position was valid for the
            // old size but is now outside the new bounds.
            val safeBounds = getSafeBounds(sizePx)
            params.x = params.x.coerceIn(safeBounds.left, safeBounds.right)
            params.y = params.y.coerceIn(safeBounds.top, safeBounds.bottom)
            preferences.savePosition(params.x, params.y)

            if (isBubbleAttached && bubbleView != null) {
                try {
                    windowManager.updateViewLayout(bubbleView, params)
                } catch (e: Exception) {
                    Log.w(TAG, "updateAppearance: updateViewLayout failed", e)
                }
            }
        }
    }

    private fun updateBubblePosition(x: Int, y: Int) {
        bubbleLayoutParams?.let { params ->
            params.x = x
            params.y = y
            if (isBubbleAttached && bubbleView != null) {
                try {
                    windowManager.updateViewLayout(bubbleView, params)
                } catch (e: Exception) {
                    Log.w(TAG, "updateBubblePosition: updateViewLayout failed", e)
                }
            }
        }
    }

    private fun handleBubbleTap() {
        resetIdleTimeout()
        if (radialOverlayView != null) {
            hideRadialMenu()
        } else {
            showRadialMenu()
        }
    }

    private fun showRadialMenu() {
        if (radialOverlayView != null) return

        val screen = getScreenDimensions()
        val density = context.resources.displayMetrics.density

        // FIX (item 17): compute required margin and scale it down if the screen
        // is too small to fit the ring at full size. Without this, coerceIn below
        // can receive min > max and throw IllegalArgumentException — a real crash
        // on foldable cover screens, some Android Go devices in landscape, and
        // split-window edge cases.
        val baseRadius = 108f * density
        val baseButtonRadius = 24f * density
        val basePadding = 8f * density
        val baseRequiredMargin = baseRadius + baseButtonRadius + basePadding

        val smallestDimension = minOf(screen.x, screen.y).toFloat()
        val maxFittingMargin = smallestDimension / 2f - (4f * density)
        val radialScale = if (baseRequiredMargin > maxFittingMargin) {
            // Floor at 0.45 so buttons remain tappable even on very small screens
            (maxFittingMargin / baseRequiredMargin).coerceIn(0.45f, 1f)
        } else {
            1f
        }
        val requiredMargin = baseRequiredMargin * radialScale

        val bubbleX = (bubbleLayoutParams?.x ?: (screen.x / 2)).toFloat()
        val bubbleY = (bubbleLayoutParams?.y ?: (screen.y / 2)).toFloat()
        val bubbleSize = preferences.bubbleSizeDp.value * density

        // Clamp radial center so the full ring fits inside the screen.
        // With requiredMargin scaled, screen.x >= 2 * requiredMargin is now guaranteed.
        val menuCenterX = (bubbleX + bubbleSize / 2f)
            .coerceIn(requiredMargin, screen.x - requiredMargin)
        val menuCenterY = (bubbleY + bubbleSize / 2f)
            .coerceIn(requiredMargin, screen.y - requiredMargin)

        val actions = preferences.activeActions.value

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            // FIX: FLAG_NOT_TOUCH_MODAL only — no full-screen touch blocker
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )

        radialOverlayView = RadialOverlayView(
            context = context,
            actions = actions,
            centerX = menuCenterX,
            centerY = menuCenterY,
            scale = radialScale,
            onActionSelected = { action ->
                if (action == QuickActionType.BACKGROUND_PLAY ||
                    action == QuickActionType.HOME ||
                    action == QuickActionType.LOCK_SCREEN
                ) {
                    hideRadialMenu()
                }
                actionController.performAction(action) { current, max, isMuted ->
                    showVolumePanel(current, max, isMuted)
                }
                if (action == QuickActionType.VOLUME_UP ||
                    action == QuickActionType.VOLUME_DOWN ||
                    action == QuickActionType.VOLUME_MUTE
                ) {
                    val info = actionController.getVolumeInfo()
                    showVolumePanel(info.first, info.second, info.third)
                }
                resetIdleTimeout()
            },
            onDismissRequested = {
                hideRadialMenu()
                resetIdleTimeout()
            }
        )

        try {
            windowManager.addView(radialOverlayView, params)
        } catch (e: Exception) {
            Log.e(TAG, "showRadialMenu: addView failed", e)
            radialOverlayView = null
        }
    }

    private fun hideRadialMenu() {
        radialOverlayView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (e: Exception) {
                Log.w(TAG, "hideRadialMenu: removeView failed", e)
            }
            radialOverlayView = null
        }
    }

    fun showVolumePanel(currentVolume: Int, maxVolume: Int, isMuted: Boolean) {
        if (volumeOverlayView != null) {
            volumeOverlayView?.updateVolume(currentVolume, maxVolume, isMuted)
            return
        }

        val density = context.resources.displayMetrics.density
        val panelWidth = (280 * density).toInt()

        val params = WindowManager.LayoutParams(
            panelWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (72 * density).toInt()
        }

        volumeOverlayView = VolumeOverlayView(
            context = context,
            streamType = preferences.defaultStreamType.value,
            initialVolume = currentVolume,
            maxVolume = maxVolume,
            initialMuted = isMuted,
            // FIX (item 33): VolumeOverlayView now passes playSound=false while
            // dragging and playSound=true on release — forward that flag to setVolume.
            onVolumeChangeRequested = { newVol, playSound ->
                actionController.setVolume(newVol, playSound) { updatedVol, max, muted ->
                    volumeOverlayView?.updateVolume(updatedVol, max, muted)
                }
                resetIdleTimeout()
            },
            onMuteToggleRequested = {
                actionController.toggleMute { updatedVol, max, muted ->
                    volumeOverlayView?.updateVolume(updatedVol, max, muted)
                }
                resetIdleTimeout()
            },
            onDismissRequested = {
                hideVolumePanel()
            }
        )

        try {
            windowManager.addView(volumeOverlayView, params)
        } catch (e: Exception) {
            Log.e(TAG, "showVolumePanel: addView failed", e)
            volumeOverlayView = null
        }
    }

    private fun hideVolumePanel() {
        volumeOverlayView?.let { panel ->
            try {
                windowManager.removeView(panel)
            } catch (e: Exception) {
                Log.w(TAG, "hideVolumePanel: removeView failed", e)
            }
            volumeOverlayView = null
        }
    }

    private fun resetIdleTimeout() {
        if (!preferences.isPermanent.value || isTemporaryMode) {
            mainHandler.removeCallbacks(autoHideRunnable)
            mainHandler.postDelayed(autoHideRunnable, 10000L)
        }
    }

    /**
     * Returns a Rect representing the area where the bubble's top-left corner
     * can be placed so the bubble remains fully on-screen.
     *
     * FIX (item 15): uses raw display bounds + an 8dp margin. It does NOT
     * carve out status bar, navigation bar, or cutout regions — this overlay
     * type (TYPE_ACCESSIBILITY_OVERLAY) is intentionally permitted to render
     * over system bars, matching how OEM assistive-touch bubbles behave.
     * If cutout/inset-avoidance becomes a product requirement, query
     * windowManager.currentWindowMetrics.windowInsets (API 30+) here to bump
     * the margin on the specific edge where a system bar sits.
     */
    private fun getSafeBounds(sizePx: Int): Rect {
        val screen = getScreenDimensions()
        val margin = (8 * context.resources.displayMetrics.density).roundToInt()
        return Rect(
            margin,                          // left
            margin,                          // top
            (screen.x - sizePx - margin),   // right (bubble right edge at screen right)
            (screen.y - sizePx - margin)    // bottom
        )
    }

    private fun getScreenDimensions(): Point {
        val size = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics = windowManager.currentWindowMetrics
            size.x = metrics.bounds.width()
            size.y = metrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getSize(size)
        }
        return size
    }
}
