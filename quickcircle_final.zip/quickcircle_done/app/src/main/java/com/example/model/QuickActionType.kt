package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.graphics.vector.ImageVector

enum class QuickActionType(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val defaultEnabled: Boolean = true
) {
    VOLUME_UP(
        id = "volume_up",
        title = "Volume +",
        subtitle = "Increase sound level",
        icon = Icons.Default.VolumeUp,
        defaultEnabled = true
    ),
    VOLUME_DOWN(
        id = "volume_down",
        title = "Volume -",
        subtitle = "Decrease sound level",
        icon = Icons.Default.VolumeDown,
        defaultEnabled = true
    ),
    VOLUME_MUTE(
        id = "volume_mute",
        title = "Mute",
        subtitle = "Toggle volume mute",
        icon = Icons.Default.VolumeOff,
        defaultEnabled = false
    ),
    SCREENSHOT(
        id = "screenshot",
        title = "Screenshot",
        subtitle = "One-tap screen capture",
        icon = Icons.Default.CameraAlt,
        defaultEnabled = true
    ),
    SPLIT_SCREEN(
        id = "split_screen",
        title = "Split Screen",
        subtitle = "Toggle app split view",
        icon = Icons.Default.VerticalSplit,
        defaultEnabled = true
    ),
    BACKGROUND_PLAY(
        id = "background_play",
        title = "Background Play",
        subtitle = "Keep supported media playing while you use other apps",
        icon = Icons.Default.PlayCircle,
        defaultEnabled = true
    ),
    LOCK_SCREEN(
        id = "lock_screen",
        title = "Lock Screen",
        subtitle = "Lock device display",
        icon = Icons.Default.Lock,
        defaultEnabled = true
    ),
    RECENTS(
        id = "recents",
        title = "Recent Apps",
        subtitle = "Switch running apps",
        icon = Icons.Default.Apps,
        defaultEnabled = true
    ),
    QUICK_SETTINGS(
        id = "quick_settings",
        title = "Quick Settings",
        subtitle = "Open system toggles",
        icon = Icons.Default.Settings,
        defaultEnabled = true
    ),
    HOME(
        id = "home",
        title = "Home",
        subtitle = "Return to home screen",
        icon = Icons.Default.Home,
        defaultEnabled = false
    ),
    NOTIFICATIONS(
        id = "notifications",
        title = "Notifications",
        subtitle = "Expand notification shade",
        icon = Icons.Default.Notifications,
        defaultEnabled = false
    ),
    MEDIA_PLAY_PAUSE(
        id = "media_play_pause",
        title = "Play / Pause",
        subtitle = "Toggle active media playback",
        icon = Icons.Default.PlayArrow,
        defaultEnabled = false
    );

    companion object {
        fun fromId(id: String): QuickActionType? = values().firstOrNull { it.id == id }

        val DEFAULT_RADIAL_ACTIONS: List<QuickActionType> = listOf(
            VOLUME_UP,
            VOLUME_DOWN,
            SCREENSHOT,
            SPLIT_SCREEN,
            BACKGROUND_PLAY,
            LOCK_SCREEN,
            RECENTS,
            QUICK_SETTINGS
        )
    }
}
