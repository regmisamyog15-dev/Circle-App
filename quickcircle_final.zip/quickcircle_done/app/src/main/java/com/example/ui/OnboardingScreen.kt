package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanAccentLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

data class OnboardingPageData(
    val pageNumber: Int,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val badge: String
)

@Composable
fun OnboardingScreen(
    isAccessibilityGranted: Boolean,
    isOverlayGranted: Boolean,
    onRequestPermission: (com.example.ui.components.PermissionDialogType) -> Unit,
    onFinishOnboarding: () -> Unit
) {
    var currentPage by remember { mutableIntStateOf(1) }

    val pages = remember {
        listOf(
            OnboardingPageData(
                pageNumber = 1,
                title = "Meet QuickCircle",
                description = "Your essential phone controls, always within reach. A clean, floating OEM-style circular controller that stays above your apps.",
                icon = Icons.Default.TouchApp,
                badge = "ESSENTIAL UTILITY"
            ),
            OnboardingPageData(
                pageNumber = 2,
                title = "Replace broken buttons",
                description = "Control volume without touching your physical volume keys. QuickCircle provides smooth on-screen software volume adjustments for media, calls, and ringers.",
                icon = Icons.Default.VolumeUp,
                badge = "HARDWARE BUTTON REPLACEMENT"
            ),
            OnboardingPageData(
                pageNumber = 3,
                title = "One tap controls",
                description = "Screenshot, Split Screen, Lock Screen, Quick Settings and more. Everything you need is laid out around an ergonomic circular ring.",
                icon = Icons.Default.Widgets,
                badge = "SYSTEM SHORTCUTS"
            ),
            OnboardingPageData(
                pageNumber = 4,
                title = "Optional Background Play",
                description = "Return to your home screen and let a supported media app keep playing in the background. QuickCircle only checks the app's own playback state — it doesn't add lock-screen controls of its own.",
                icon = Icons.Default.PlayCircle,
                badge = "MEDIA MULTITASKING"
            ),
            OnboardingPageData(
                pageNumber = 5,
                title = "Enable Accessibility",
                description = "QuickCircle requires Accessibility Service and Overlay permission to display floating controls and execute standard system actions like volume, screenshots, and split screen without root.",
                icon = Icons.Default.Accessibility,
                badge = "SETUP & PERMISSIONS"
            )
        )
    }

    val pageData = pages[currentPage - 1]

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Progress Dots & Skip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (i in 1..5) {
                        Box(
                            modifier = Modifier
                                .size(width = if (i == currentPage) 24.dp else 8.dp, height = 8.dp)
                                .clip(CircleShape)
                                .background(if (i == currentPage) CyanAccentLight else Slate700)
                        )
                    }
                }

                if (currentPage < 5) {
                    FilledTonalButton(
                        onClick = { currentPage = 5 },
                        modifier = Modifier.testTag("skip_button")
                    ) {
                        Text("Skip")
                    }
                }
            }

            // Animated Center Body
            AnimatedContent(
                targetState = pageData,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "onboarding_animation"
            ) { data ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Slate800)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = data.badge,
                            color = CyanAccentLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Large Emblem
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Slate800),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = data.icon,
                            contentDescription = data.title,
                            tint = CyanAccentLight,
                            modifier = Modifier.size(52.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Title
                    Text(
                        text = data.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Description
                    Text(
                        text = data.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Slate400,
                        textAlign = TextAlign.Center,
                        lineHeight = 24.sp
                    )

                    // If Page 5: Permission Buttons
                    if (data.pageNumber == 5) {
                        Spacer(modifier = Modifier.height(24.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Slate900),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Accessibility button
                                Button(
                                    onClick = {
                                        onRequestPermission(com.example.ui.components.PermissionDialogType.ACCESSIBILITY)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("enable_accessibility_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isAccessibilityGranted) EmeraldSuccess else Slate800
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isAccessibilityGranted) Icons.Default.Check else Icons.Default.Accessibility,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(8.dp))
                                    Text(
                                        text = if (isAccessibilityGranted) "Accessibility Enabled" else "Request Accessibility",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                // Overlay button
                                Button(
                                    onClick = {
                                        onRequestPermission(com.example.ui.components.PermissionDialogType.OVERLAY)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("allow_overlay_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isOverlayGranted) EmeraldSuccess else Slate800
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isOverlayGranted) Icons.Default.Check else Icons.Default.Layers,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(8.dp))
                                    Text(
                                        text = if (isOverlayGranted) "Overlay Allowed" else "Request Overlay",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Navigation Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentPage > 1) {
                    IconButton(
                        onClick = { currentPage-- },
                        modifier = Modifier.testTag("prev_page_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Previous Page",
                            tint = Slate400
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(48.dp))
                }

                if (currentPage < 5) {
                    Button(
                        onClick = { currentPage++ },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccentLight),
                        modifier = Modifier.testTag("next_page_button")
                    ) {
                        Text("Next", color = Slate900, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.size(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Slate900,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    Button(
                        onClick = onFinishOnboarding,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccentLight),
                        modifier = Modifier.testTag("finish_onboarding_button")
                    ) {
                        Text("Start Using QuickCircle", color = Slate900, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
