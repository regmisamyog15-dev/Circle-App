package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.BatteryMode
import com.example.model.DockEdge
import com.example.model.QuickActionType
import com.example.model.StreamType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class QuickCirclePreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("quick_circle_preferences", Context.MODE_PRIVATE)

    // State Flows for reactive Compose UI & background services
    private val _isEnabled = MutableStateFlow(prefs.getBoolean(KEY_IS_ENABLED, true))
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val _isPermanent = MutableStateFlow(prefs.getBoolean(KEY_IS_PERMANENT, true))
    val isPermanent: StateFlow<Boolean> = _isPermanent.asStateFlow()

    private val _bubbleSizeDp = MutableStateFlow(prefs.getInt(KEY_BUBBLE_SIZE_DP, 52))
    val bubbleSizeDp: StateFlow<Int> = _bubbleSizeDp.asStateFlow()

    private val _bubbleOpacity = MutableStateFlow(prefs.getFloat(KEY_BUBBLE_OPACITY, 0.85f))
    val bubbleOpacity: StateFlow<Float> = _bubbleOpacity.asStateFlow()

    private val _dockEdge = MutableStateFlow(
        safeEnumValueOf(prefs.getString(KEY_DOCK_EDGE, null), DockEdge.AUTO)
    )
    val dockEdge: StateFlow<DockEdge> = _dockEdge.asStateFlow()

    private val _positionX = MutableStateFlow(prefs.getInt(KEY_POSITION_X, -1))
    val positionX: StateFlow<Int> = _positionX.asStateFlow()

    private val _positionY = MutableStateFlow(prefs.getInt(KEY_POSITION_Y, -1))
    val positionY: StateFlow<Int> = _positionY.asStateFlow()

    private val _isTripleTapEnabled = MutableStateFlow(prefs.getBoolean(KEY_TRIPLE_TAP_ENABLED, true))
    val isTripleTapEnabled: StateFlow<Boolean> = _isTripleTapEnabled.asStateFlow()

    private val _tripleTapSensitivityMs = MutableStateFlow(prefs.getLong(KEY_TRIPLE_TAP_SENSITIVITY, 800L))
    val tripleTapSensitivityMs: StateFlow<Long> = _tripleTapSensitivityMs.asStateFlow()

    private val _batteryMode = MutableStateFlow(
        safeEnumValueOf(prefs.getString(KEY_BATTERY_MODE, null), BatteryMode.NORMAL)
    )
    val batteryMode: StateFlow<BatteryMode> = _batteryMode.asStateFlow()

    private val _activeActions = MutableStateFlow(loadActions())
    val activeActions: StateFlow<List<QuickActionType>> = _activeActions.asStateFlow()

    private val _isSoftwareVolumeReplacementEnabled = MutableStateFlow(
        prefs.getBoolean(KEY_SOFTWARE_VOLUME_REPLACEMENT, true)
    )
    val isSoftwareVolumeReplacementEnabled: StateFlow<Boolean> = _isSoftwareVolumeReplacementEnabled.asStateFlow()

    private val _defaultStreamType = MutableStateFlow(
        safeEnumValueOf(prefs.getString(KEY_DEFAULT_STREAM_TYPE, null), StreamType.MUSIC)
    )
    val defaultStreamType: StateFlow<StreamType> = _defaultStreamType.asStateFlow()

    private val _isBackgroundPlayEnabled = MutableStateFlow(prefs.getBoolean(KEY_BG_PLAY_ENABLED, true))
    val isBackgroundPlayEnabled: StateFlow<Boolean> = _isBackgroundPlayEnabled.asStateFlow()

    private val _resumePausedMedia = MutableStateFlow(prefs.getBoolean(KEY_RESUME_PAUSED_MEDIA, false))
    val resumePausedMedia: StateFlow<Boolean> = _resumePausedMedia.asStateFlow()

    // NOTE (item 14 audit): "Show media controls on lock screen" and a PiP
    // preference used to live here but were never wired to any real behavior —
    // QuickCircle does not own the target app's MediaSession or its lock-screen
    // presentation, and does not implement Picture-in-Picture. Dead settings
    // that can't actually be controlled were removed rather than kept "just in
    // case"; re-add only alongside a real, working implementation.

    private val _hasCompletedOnboarding = MutableStateFlow(prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false))
    val hasCompletedOnboarding: StateFlow<Boolean> = _hasCompletedOnboarding.asStateFlow()

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_IS_ENABLED, enabled).apply()
        _isEnabled.value = enabled
    }

    fun setPermanent(permanent: Boolean) {
        prefs.edit().putBoolean(KEY_IS_PERMANENT, permanent).apply()
        _isPermanent.value = permanent
    }

    fun setBubbleSizeDp(size: Int) {
        prefs.edit().putInt(KEY_BUBBLE_SIZE_DP, size).apply()
        _bubbleSizeDp.value = size
    }

    fun setBubbleOpacity(opacity: Float) {
        prefs.edit().putFloat(KEY_BUBBLE_OPACITY, opacity).apply()
        _bubbleOpacity.value = opacity
    }

    fun setDockEdge(edge: DockEdge) {
        prefs.edit().putString(KEY_DOCK_EDGE, edge.name).apply()
        _dockEdge.value = edge
    }

    fun savePosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_POSITION_X, x).putInt(KEY_POSITION_Y, y).apply()
        _positionX.value = x
        _positionY.value = y
    }

    fun setTripleTapEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_TRIPLE_TAP_ENABLED, enabled).apply()
        _isTripleTapEnabled.value = enabled
    }

    fun setTripleTapSensitivityMs(ms: Long) {
        prefs.edit().putLong(KEY_TRIPLE_TAP_SENSITIVITY, ms).apply()
        _tripleTapSensitivityMs.value = ms
    }

    fun setBatteryMode(mode: BatteryMode) {
        prefs.edit().putString(KEY_BATTERY_MODE, mode.name).apply()
        _batteryMode.value = mode
    }

    /**
     * FIX (item 29): dedupe before persisting/publishing so the radial wheel can
     * never contain the same action twice, regardless of caller.
     */
    fun setActiveActions(actions: List<QuickActionType>) {
        val deduped = actions.distinct()
        val serialized = deduped.joinToString(",") { it.id }
        prefs.edit().putString(KEY_ACTIVE_ACTIONS, serialized).apply()
        _activeActions.value = deduped
    }

    /**
     * FIX (item 30): the real floor is 1, not an arbitrary 2. With zero actions
     * the radial wheel would have nothing to show or tap, so we require at
     * least one action to remain selected; RadialOverlayView renders and
     * hit-tests correctly with a single action (see its onDraw/onTouchEvent).
     */
    fun toggleAction(action: QuickActionType) {
        val current = _activeActions.value.toMutableList()
        if (current.contains(action)) {
            if (current.size > 1) {
                current.remove(action)
            }
        } else {
            current.add(action)
        }
        setActiveActions(current)
    }

    fun setSoftwareVolumeReplacement(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOFTWARE_VOLUME_REPLACEMENT, enabled).apply()
        _isSoftwareVolumeReplacementEnabled.value = enabled
    }

    fun setDefaultStreamType(streamType: StreamType) {
        prefs.edit().putString(KEY_DEFAULT_STREAM_TYPE, streamType.name).apply()
        _defaultStreamType.value = streamType
    }

    fun setBackgroundPlayEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BG_PLAY_ENABLED, enabled).apply()
        _isBackgroundPlayEnabled.value = enabled
    }

    fun setResumePausedMedia(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_RESUME_PAUSED_MEDIA, enabled).apply()
        _resumePausedMedia.value = enabled
    }

    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, completed).apply()
        _hasCompletedOnboarding.value = completed
    }

    private fun loadActions(): List<QuickActionType> {
        val saved = prefs.getString(KEY_ACTIVE_ACTIONS, null)
        if (saved.isNullOrEmpty()) {
            return QuickActionType.DEFAULT_RADIAL_ACTIONS
        }
        // .distinct() guards against a duplicate slipping in from a value
        // persisted before the item-29 fix to setActiveActions().
        val items = saved.split(",").mapNotNull { QuickActionType.fromId(it.trim()) }.distinct()
        return if (items.isNotEmpty()) items else QuickActionType.DEFAULT_RADIAL_ACTIONS
    }

    /**
     * FIX (item 28): corrupted or stale enum text stored in SharedPreferences
     * (e.g. left over from an older app version that had different enum
     * constants) must never crash startup. `Enum.valueOf()` throws
     * IllegalArgumentException on a no-longer-valid name; we catch that and
     * fall back to the given default instead of letting it propagate.
     */
    private inline fun <reified T : Enum<T>> safeEnumValueOf(stored: String?, default: T): T {
        if (stored == null) return default
        return try {
            enumValueOf<T>(stored)
        } catch (e: IllegalArgumentException) {
            default
        }
    }

    companion object {
        private const val KEY_IS_ENABLED = "is_enabled"
        private const val KEY_IS_PERMANENT = "is_permanent"
        private const val KEY_BUBBLE_SIZE_DP = "bubble_size_dp"
        private const val KEY_BUBBLE_OPACITY = "bubble_opacity"
        private const val KEY_DOCK_EDGE = "dock_edge"
        private const val KEY_POSITION_X = "position_x"
        private const val KEY_POSITION_Y = "position_y"
        private const val KEY_TRIPLE_TAP_ENABLED = "triple_tap_enabled"
        private const val KEY_TRIPLE_TAP_SENSITIVITY = "triple_tap_sensitivity"
        private const val KEY_BATTERY_MODE = "battery_mode"
        private const val KEY_ACTIVE_ACTIONS = "active_actions"
        private const val KEY_SOFTWARE_VOLUME_REPLACEMENT = "software_volume_replacement"
        private const val KEY_DEFAULT_STREAM_TYPE = "default_stream_type"
        private const val KEY_BG_PLAY_ENABLED = "bg_play_enabled"
        private const val KEY_RESUME_PAUSED_MEDIA = "resume_paused_media"
        private const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"

        @Volatile
        private var INSTANCE: QuickCirclePreferences? = null

        fun getInstance(context: Context): QuickCirclePreferences {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: QuickCirclePreferences(context.applicationContext).also { INSTANCE = it }
            }
        }

        /**
         * FIX (item 35, test isolation only): clears the cached singleton and the
         * backing SharedPreferences file so tests don't leak state across test
         * methods/classes via the process-local INSTANCE cache. Not for
         * production use.
         */
        @androidx.annotation.VisibleForTesting
        fun resetForTesting(context: Context) {
            synchronized(this) {
                context.applicationContext
                    .getSharedPreferences("quick_circle_preferences", Context.MODE_PRIVATE)
                    .edit().clear().apply()
                INSTANCE = null
            }
        }
    }
}
