package com.example.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.example.R
import com.example.model.StreamType

@SuppressLint("ViewConstructor")
class VolumeOverlayView(
    context: Context,
    private val streamType: StreamType,
    initialVolume: Int,
    private val maxVolume: Int,
    initialMuted: Boolean,
    // FIX (item 33): callback now carries playSound. false while dragging,
    // true on release and for discrete +/- button taps.
    private val onVolumeChangeRequested: (volume: Int, playSound: Boolean) -> Unit,
    private val onMuteToggleRequested: () -> Unit,
    private val onDismissRequested: () -> Unit
) : LinearLayout(context) {

    private val density = resources.displayMetrics.density
    private val mainHandler = Handler(Looper.getMainLooper())
    private val autoDismissRunnable = Runnable { dismissWithAnimation() }

    private val titleText: TextView
    private val valueText: TextView
    private val seekBar: SeekBar
    private val muteButton: ImageView

    private var currentVolume = initialVolume
    private var isMuted = initialMuted

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())

        // Modern Slate OEM glass background
        background = GradientDrawable().apply {
            setColor(Color.argb(240, 15, 23, 42))
            cornerRadius = 20f * density
            setStroke((1.5f * density).toInt(), Color.argb(100, 56, 189, 248))
        }

        elevation = 16f * density

        // Top Header Row
        val headerRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }

        titleText = TextView(context).apply {
            text = "${streamType.title} Volume"
            setTextColor(Color.rgb(248, 250, 252))
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }

        valueText = TextView(context).apply {
            text = if (isMuted) "Muted" else "$currentVolume / $maxVolume"
            setTextColor(Color.rgb(148, 163, 184))
            textSize = 12f
            setPadding(0, 0, (8 * density).toInt(), 0)
        }

        muteButton = ImageView(context).apply {
            setImageResource(if (isMuted) R.drawable.ic_action_volume_mute else R.drawable.ic_action_volume_up)
            setColorFilter(if (isMuted) Color.rgb(244, 63, 94) else Color.rgb(56, 189, 248))
            val pad = (4 * density).toInt()
            setPadding(pad, pad, pad, pad)
            val btnSize = (28 * density).toInt()
            layoutParams = LayoutParams(btnSize, btnSize)
            setOnClickListener {
                resetAutoDismiss()
                onMuteToggleRequested()
            }
        }

        headerRow.addView(titleText)
        headerRow.addView(valueText)
        headerRow.addView(muteButton)
        addView(headerRow)

        // Bottom Slider Row
        val sliderRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, (10 * density).toInt(), 0, 0)
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        }

        val minusBtn = ImageView(context).apply {
            setImageResource(R.drawable.ic_action_minus)
            setColorFilter(Color.rgb(226, 232, 240))
            val btnSize = (24 * density).toInt()
            layoutParams = LayoutParams(btnSize, btnSize)
            setOnClickListener {
                resetAutoDismiss()
                val next = (currentVolume - 1).coerceAtLeast(0)
                onVolumeChangeRequested(next, true) // discrete tap — play sound
            }
        }

        seekBar = SeekBar(context).apply {
            max = maxVolume
            progress = currentVolume
            layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins((6 * density).toInt(), 0, (6 * density).toInt(), 0)
            }
            // FIX (item 33): suppress FLAG_PLAY_SOUND while dragging — each pixel
            // of drag was firing a system beep, producing audio spam. Now beep only
            // fires once, on release (onStopTrackingTouch). Discrete +/- taps below
            // keep playSound=true since each is already a deliberate discrete action.
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        resetAutoDismiss()
                        onVolumeChangeRequested(progress, false) // suppress during drag
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { resetAutoDismiss() }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    resetAutoDismiss()
                    // One sound on finger-up — the user has committed to a level
                    onVolumeChangeRequested(seekBar.progress, true)
                }
            })
        }

        val plusBtn = ImageView(context).apply {
            setImageResource(R.drawable.ic_action_plus)
            setColorFilter(Color.rgb(226, 232, 240))
            val btnSize = (24 * density).toInt()
            layoutParams = LayoutParams(btnSize, btnSize)
            setOnClickListener {
                resetAutoDismiss()
                val next = (currentVolume + 1).coerceAtMost(maxVolume)
                onVolumeChangeRequested(next, true) // discrete tap — play sound
            }
        }

        sliderRow.addView(minusBtn)
        sliderRow.addView(seekBar)
        sliderRow.addView(plusBtn)
        addView(sliderRow)

        resetAutoDismiss()
    }

    fun updateVolume(newVolume: Int, max: Int, muted: Boolean) {
        currentVolume = newVolume
        isMuted = muted
        seekBar.max = max
        seekBar.progress = newVolume
        valueText.text = if (isMuted) "Muted" else "$newVolume / $max"
        muteButton.setImageResource(if (isMuted) R.drawable.ic_action_volume_mute else R.drawable.ic_action_volume_up)
        muteButton.setColorFilter(if (isMuted) Color.rgb(244, 63, 94) else Color.rgb(56, 189, 248))
        resetAutoDismiss()
    }

    private fun resetAutoDismiss() {
        mainHandler.removeCallbacks(autoDismissRunnable)
        mainHandler.postDelayed(autoDismissRunnable, 3500L)
    }

    fun dismissWithAnimation() {
        mainHandler.removeCallbacks(autoDismissRunnable)
        val animator = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 180L
            addUpdateListener {
                val alpha = it.animatedValue as Float
                setAlpha(alpha)
                scaleX = 0.9f + 0.1f * alpha
                scaleY = 0.9f + 0.1f * alpha
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onDismissRequested()
                }
            })
        }
        animator.start()
    }
}
