package com.example

import android.content.Context
import android.graphics.Point
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.example.data.QuickCirclePreferences
import com.example.model.BatteryMode
import com.example.model.DockEdge
import com.example.model.QuickActionType
import com.example.model.StreamType
import com.example.service.SystemActionController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class QuickCircleRobolectricTest {

    private lateinit var context: Context
    private lateinit var preferences: QuickCirclePreferences

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        // FIX (item 35): clear SharedPreferences + singleton before every test
        // so each test starts from real defaults regardless of run order or
        // Robolectric's classloader-reset behaviour.
        QuickCirclePreferences.resetForTesting(context)
        preferences = QuickCirclePreferences.getInstance(context)
    }

    // ─── PREFERENCES ─────────────────────────────────────────────────────────

    @Test
    fun `preferences default values are correct`() {
        assertTrue(preferences.isEnabled.value)
        assertTrue(preferences.isPermanent.value)
        assertEquals(52, preferences.bubbleSizeDp.value)
        assertEquals(0.85f, preferences.bubbleOpacity.value, 0.01f)
        assertEquals(DockEdge.AUTO, preferences.dockEdge.value)
        assertTrue(preferences.isTripleTapEnabled.value)
        assertEquals(BatteryMode.NORMAL, preferences.batteryMode.value)
        assertTrue(preferences.isSoftwareVolumeReplacementEnabled.value)
        assertEquals(StreamType.MUSIC, preferences.defaultStreamType.value)
        assertTrue(preferences.isBackgroundPlayEnabled.value)
        assertFalse(preferences.resumePausedMedia.value)
    }

    @Test
    fun `preferences mutation updates state flows`() {
        preferences.setEnabled(false)
        assertFalse(preferences.isEnabled.value)

        preferences.setEnabled(true)
        assertTrue(preferences.isEnabled.value)

        preferences.setPermanent(false)
        assertFalse(preferences.isPermanent.value)

        preferences.setBubbleSizeDp(60)
        assertEquals(60, preferences.bubbleSizeDp.value)

        preferences.setBubbleOpacity(0.5f)
        assertEquals(0.5f, preferences.bubbleOpacity.value, 0.01f)

        preferences.setDockEdge(DockEdge.LEFT)
        assertEquals(DockEdge.LEFT, preferences.dockEdge.value)

        preferences.setBatteryMode(BatteryMode.BATTERY_SAVER)
        assertEquals(BatteryMode.BATTERY_SAVER, preferences.batteryMode.value)

        preferences.setBatteryMode(BatteryMode.ULTRA_BATTERY)
        assertEquals(BatteryMode.ULTRA_BATTERY, preferences.batteryMode.value)
    }

    @Test
    fun `position saved and restored correctly`() {
        preferences.savePosition(300, 600)
        assertEquals(300, preferences.positionX.value)
        assertEquals(600, preferences.positionY.value)

        preferences.savePosition(-1, -1)
        assertEquals(-1, preferences.positionX.value)
        assertEquals(-1, preferences.positionY.value)
    }

    @Test
    fun `radial actions customization maintains minimum of two actions`() {
        val initial = preferences.activeActions.value
        assertTrue("Must have at least 2 actions initially", initial.size >= 2)

        // Add an action
        preferences.toggleAction(QuickActionType.HOME)
        assertTrue(preferences.activeActions.value.contains(QuickActionType.HOME))

        // Remove it
        preferences.toggleAction(QuickActionType.HOME)
        assertFalse(preferences.activeActions.value.contains(QuickActionType.HOME))

        // Reduce to minimum (2) then try removing — should stay at 2
        val currentActions = preferences.activeActions.value.toMutableList()
        while (preferences.activeActions.value.size > 2) {
            preferences.toggleAction(preferences.activeActions.value.last())
        }
        assertEquals(2, preferences.activeActions.value.size)

        // Try removing one more — should be blocked
        val lastAction = preferences.activeActions.value.last()
        preferences.toggleAction(lastAction)
        assertEquals(2, preferences.activeActions.value.size)
        assertTrue(preferences.activeActions.value.contains(lastAction))
    }

    @Test
    fun `action serialization round-trips correctly`() {
        val actions = listOf(
            QuickActionType.VOLUME_UP,
            QuickActionType.SCREENSHOT,
            QuickActionType.HOME
        )
        preferences.setActiveActions(actions)
        val loaded = preferences.activeActions.value
        assertEquals(actions.size, loaded.size)
        assertEquals(actions[0], loaded[0])
        assertEquals(actions[1], loaded[1])
        assertEquals(actions[2], loaded[2])
    }

    @Test
    fun `triple-tap sensitivity range is valid`() {
        preferences.setTripleTapSensitivityMs(500L)
        assertEquals(500L, preferences.tripleTapSensitivityMs.value)

        preferences.setTripleTapSensitivityMs(1200L)
        assertEquals(1200L, preferences.tripleTapSensitivityMs.value)
    }

    // ─── VOLUME ──────────────────────────────────────────────────────────────

    @Test
    fun `volume controller initializes without crash`() {
        val controller = SystemActionController(context) { null }
        val info = controller.getVolumeInfo()
        assertTrue("Max volume must be positive", info.second > 0)
        assertTrue("Current volume must be in range", info.first in 0..info.second)
    }

    @Test
    fun `volume adjust does not crash when service is null`() {
        val controller = SystemActionController(context) { null }
        // These should not throw
        controller.adjustVolume(1) { current, max, _ ->
            assertTrue(current in 0..max)
        }
        controller.adjustVolume(-1) { current, max, _ ->
            assertTrue(current in 0..max)
        }
    }

    @Test
    fun `mute toggle does not crash when service is null`() {
        val controller = SystemActionController(context) { null }
        controller.toggleMute { current, max, _ ->
            assertTrue(current in 0..max)
        }
    }

    @Test
    fun `setVolume clamps to valid range in practice`() {
        val controller = SystemActionController(context) { null }
        val (_, max, _) = controller.getVolumeInfo()
        // Set to max
        controller.setVolume(max) { current, returnedMax, _ ->
            assertTrue(current <= returnedMax)
        }
        // Set to 0
        controller.setVolume(0) { current, _, _ ->
            assertTrue(current >= 0)
        }
    }

    // ─── POSITION CLAMPING LOGIC ─────────────────────────────────────────────
    // Tests the clamping math used by FloatingBubbleManager

    @Test
    fun `bubble position clamps to safe bounds`() {
        val sizePx = 160
        val margin = 24
        val screenW = 1080
        val screenH = 2400

        val safeBounds = Rect(
            margin,
            margin,
            screenW - sizePx - margin,
            screenH - sizePx - margin
        )

        // Position beyond right edge should clamp
        val rawX = 1200
        val clampedX = rawX.coerceIn(safeBounds.left, safeBounds.right)
        assertTrue("Clamped X should be <= right bound", clampedX <= safeBounds.right)
        assertTrue("Clamped X should be >= left bound", clampedX >= safeBounds.left)

        // Position above top edge
        val rawY = -50
        val clampedY = rawY.coerceIn(safeBounds.top, safeBounds.bottom)
        assertTrue("Clamped Y should be >= top bound", clampedY >= safeBounds.top)
    }

    @Test
    fun `bubble default position is on right edge at 45 percent height`() {
        val sizePx = 160
        val margin = 24
        val screenW = 1080
        val screenH = 2400
        val safeBounds = Rect(margin, margin, screenW - sizePx - margin, screenH - sizePx - margin)

        val defaultX = safeBounds.right
        val defaultY = ((safeBounds.top + safeBounds.bottom) * 0.45f).toInt()

        assertTrue(defaultX > 0)
        assertTrue(defaultY > 0)
        assertTrue(defaultX <= safeBounds.right)
        assertTrue(defaultY <= safeBounds.bottom)
    }

    // ─── RADIAL MENU MARGIN LOGIC ─────────────────────────────────────────────

    @Test
    fun `radial margin is larger than hardcoded 130dp for standard density`() {
        val density = 3.0f  // xxhdpi
        val radialRadius = 108f * density
        val buttonRadius = 24f * density
        val extraPadding = 8f * density
        val requiredMargin = radialRadius + buttonRadius + extraPadding

        val oldHardcoded = 130f * density

        assertTrue(
            "Dynamic margin ($requiredMargin) should be >= old hardcoded ($oldHardcoded) to ensure nothing clips",
            requiredMargin >= oldHardcoded
        )
    }

    // ─── BACKGROUND PLAY LOGIC ───────────────────────────────────────────────

    @Test
    fun `background play aborts when disabled in preferences`() {
        val controller = SystemActionController(context) { null }
        preferences.setBackgroundPlayEnabled(false)
        // Should return early with toast, not throw
        controller.activateBackgroundPlay()
        // Re-enable for other tests
        preferences.setBackgroundPlayEnabled(true)
    }

    @Test
    fun `background play reports no media when no notification listener connected`() {
        val controller = SystemActionController(context) { null }
        preferences.setBackgroundPlayEnabled(true)
        // NotificationListenerService is not connected in unit tests,
        // so getActiveControllers returns empty list.
        // activateBackgroundPlay should handle this gracefully (no crash).
        controller.activateBackgroundPlay()
    }

    // ─── BACKGROUND PLAY SELECTION LOGIC ─────────────────────────────────────
    // Tests for the pure selectBackgroundPlayTarget function (item 37).
    // MediaController is a final Android class — we test the selection predicates
    // by driving selectBackgroundPlayTarget with an empty list (unit-testable
    // without mocking MediaController) and verify the foreground-package and
    // allow-paused logic through the public interface path.

    @Test
    fun `selectBackgroundPlayTarget returns null when controller list is empty`() {
        val controller = SystemActionController(context) { null }
        val result = controller.selectBackgroundPlayTarget(
            controllers = emptyList(),
            foregroundPackage = "com.example.app",
            allowResumingPaused = true
        )
        // With no sessions there is nothing to select — must return null, not crash
        assertEquals(null, result)
    }

    @Test
    fun `selectBackgroundPlayTarget returns null with no foreground package and empty list`() {
        val controller = SystemActionController(context) { null }
        val result = controller.selectBackgroundPlayTarget(
            controllers = emptyList(),
            foregroundPackage = null,
            allowResumingPaused = false
        )
        assertEquals(null, result)
    }

    @Test
    fun `selectBackgroundPlayTarget is null-safe for allowResumingPaused false with empty list`() {
        val controller = SystemActionController(context) { null }
        // Paused sessions requested but none exist — must return null, not crash
        val result = controller.selectBackgroundPlayTarget(
            controllers = emptyList(),
            foregroundPackage = null,
            allowResumingPaused = true
        )
        assertEquals(null, result)
    }

    // ─── STREAM TYPES ────────────────────────────────────────────────────────

    @Test
    fun `all stream types have valid stream IDs`() {
        StreamType.values().forEach { streamType ->
            assertTrue("Stream ID for ${streamType.name} must be non-negative", streamType.streamId >= 0)
        }
    }

    @Test
    fun `stream type preference round-trips`() {
        StreamType.values().forEach { type ->
            preferences.setDefaultStreamType(type)
            assertEquals(type, preferences.defaultStreamType.value)
        }
    }

    // ─── BATTERY MODES ───────────────────────────────────────────────────────

    @Test
    fun `all battery modes have non-empty titles and descriptions`() {
        BatteryMode.values().forEach { mode ->
            assertTrue("Battery mode ${mode.name} must have a title", mode.title.isNotBlank())
            assertTrue("Battery mode ${mode.name} must have a description", mode.description.isNotBlank())
        }
    }

    @Test
    fun `ultra battery description does not claim zero background processing`() {
        val desc = BatteryMode.ULTRA_BATTERY.description
        assertFalse(
            "ULTRA_BATTERY description must not claim 'zero background processing'",
            desc.contains("zero background processing", ignoreCase = true)
        )
    }

    // ─── ACTION TYPES ────────────────────────────────────────────────────────

    @Test
    fun `all action types have unique IDs`() {
        val ids = QuickActionType.values().map { it.id }
        assertEquals("All action IDs must be unique", ids.size, ids.toSet().size)
    }

    @Test
    fun `fromId resolves each action correctly`() {
        QuickActionType.values().forEach { action ->
            val resolved = QuickActionType.fromId(action.id)
            assertNotNull("fromId must resolve ${action.id}", resolved)
            assertEquals(action, resolved)
        }
    }

    @Test
    fun `fromId returns null for unknown ID`() {
        val resolved = QuickActionType.fromId("this_does_not_exist")
        assertEquals(null, resolved)
    }
}
