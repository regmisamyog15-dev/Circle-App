# Gradle Wrapper Setup

This project includes `gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.properties`.

**One file is missing: `gradle/wrapper/gradle-wrapper.jar`**

The JAR is a binary file (~60KB) that cannot be committed or generated without a running
Gradle installation. It was not present in the source ZIP.

## To complete the wrapper (one-time setup)

### Option A — If you have Gradle installed
```bash
gradle wrapper --gradle-version 9.3.1
```
This regenerates all wrapper files including the JAR.

### Option B — Download the JAR directly
```bash
curl -L -o gradle/wrapper/gradle-wrapper.jar \
  "https://raw.githubusercontent.com/gradle/gradle/v9.3.1/gradle/wrapper/gradle-wrapper.jar"
```

### Option C — Use Android Studio
Open the project in Android Studio. It will detect the missing JAR and offer to
download it automatically.

## After setup
```bash
./gradlew clean
./gradlew test
./gradlew assembleDebug
```

## JDK Requirement
This project targets Java 11 compatibility. Use **JDK 11 or JDK 17** (recommended).
AGP 9.1.1 requires JDK 17+.
